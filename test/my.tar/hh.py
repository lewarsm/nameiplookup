import tkinter as tk

def update_visibility():
    """Hide rows with empty entries."""
    for row_index, entry in enumerate(entries):
        if entry.get().strip():  # If the entry is not empty, show the row
            for widget in entry_widgets[row_index]:
                widget.grid()
        else:  # If the entry is empty, hide the row
            for widget in entry_widgets[row_index]:
                widget.grid_remove()

# Create the main window
root = tk.Tk()
root.title("Scrollable Example")

# Create a frame with a canvas and scrollbar
frame = tk.Frame(root)
frame.pack(fill=tk.BOTH, expand=True)

canvas = tk.Canvas(frame)
scrollbar = tk.Scrollbar(frame, orient=tk.VERTICAL, command=canvas.yview)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

canvas.configure(yscrollcommand=scrollbar.set)

# Create another frame inside the canvas for content
content_frame = tk.Frame(canvas)
canvas.create_window((0, 0), window=content_frame, anchor="nw")

# Add content dynamically
entries = []
entry_widgets = []

for i in range(15):  # Add more rows for demonstration
    label = tk.Label(content_frame, text=f"Row {i + 1}:")
    entry = tk.Entry(content_frame)

    entries.append(entry)
    entry_widgets.append([label, entry])

    label.grid(row=i, column=0, padx=5, pady=5)
    entry.grid(row=i, column=1, padx=5, pady=5)

# Configure canvas scrolling
def configure_scrollregion(event):
    canvas.configure(scrollregion=canvas.bbox("all"))

content_frame.bind("<Configure>", configure_scrollregion)

# Add a button to trigger the update
update_button = tk.Button(content_frame, text="Update Visibility", command=update_visibility)
update_button.grid(row=15, column=0, columnspan=2, pady=10)

root.mainloop()

