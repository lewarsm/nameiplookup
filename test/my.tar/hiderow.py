import tkinter as tk

def update_visibility():
    """Hide rows with empty entries."""
    for row_index, entry in enumerate(entries):
        if entry.get().strip():  # If the entry is not empty, show the row
            for widget in entry_widgets[row_index]:
                widget.grid()
        else:  # If the entry is empty, hide the row
            for widget in entry_widgets[row_index]:
                widget.grid_remove()

# Create the main window
root = tk.Tk()
root.title("Hide Empty Rows")

# Create a list to store entry widgets
entries = []
entry_widgets = []  # To track all widgets in each row

# Add sample rows with labels and entries
for i in range(5):
    label = tk.Label(root, text=f"Row {i + 1}:")
    entry = tk.Entry(root)

    # Track widgets for the row
    entries.append(entry)
    entry_widgets.append([label, entry])

    # Add widgets to the grid
    label.grid(row=i, column=0, padx=5, pady=5)
    entry.grid(row=i, column=1, padx=5, pady=5)

# Add a button to trigger the update
update_button = tk.Button(root, text="Update Visibility", command=update_visibility)
update_button.grid(row=5, column=0, columnspan=2, pady=10)

# Start the Tkinter main loop
root.mainloop()

