import tkinter as tk
from tkinter import ttk
import random

# Generate random data for the tables
def generate_random_names():
    first_names = ["Alice", "Bob", "Charlie", "Diana", "Eve"]
    last_names = ["Smith", "Johnson", "Brown", "Taylor", "Anderson"]
    return random.choice(first_names), random.choice(last_names)

def generate_random_car_data():
    manufacturers = ["Toyota", "Ford", "Honda", "Chevrolet", "BMW"]
    models = ["Camry", "F-150", "Civic", "Silverado", "3 Series"]
    engine_sizes = ["2.5L", "3.0L", "1.8L", "4.3L", "2.0L"]
    prices = ["$20,000", "$30,000", "$25,000", "$35,000", "$40,000"]
    trade_in_values = ["$5,000", "$7,000", "$6,000", "$8,000", "$10,000"]

    return (random.choice(manufacturers), random.choice(models), 
            random.choice(engine_sizes), random.choice(prices), 
            random.choice(trade_in_values))

# Create the main application window
root = tk.Tk()
root.title("Two Tables Example")
root.geometry("600x300")

# Create a frame for the tables
frame = tk.Frame(root)
frame.pack(fill=tk.BOTH, expand=True)

# Table 1: Names
tree1 = ttk.Treeview(frame, columns=("First Name", "Last Name"), show="headings")
tree1.heading("First Name", text="First Name")
tree1.heading("Last Name", text="Last Name")
tree1.column("First Name", width=150, anchor="center")
tree1.column("Last Name", width=150, anchor="center")

tree1.grid(row=0, column=0, columnspan=5, sticky="nsew")

# Add random data to Table 1
first_name, last_name = generate_random_names()
tree1.insert("", tk.END, values=(first_name, last_name))
tree1.insert("", tk.END, values=(generate_random_names()))

# Table 2: Car Data
tree2 = ttk.Treeview(frame, columns=("Manufacturer", "Model", "Engine Size", "Price", "Trade-In Value"), show="headings")
for col in ["Manufacturer", "Model", "Engine Size", "Price", "Trade-In Value"]:
    tree2.heading(col, text=col)
    tree2.column(col, width=100, anchor="center")

tree2.grid(row=1, column=0, columnspan=5, sticky="nsew")

# Add random data to Table 2
for _ in range(3):
    tree2.insert("", tk.END, values=generate_random_car_data())

# Configure grid weights
frame.rowconfigure(0, weight=1)
frame.rowconfigure(1, weight=1)
frame.columnconfigure(0, weight=1)
frame.columnconfigure(1, weight=1)
frame.columnconfigure(2, weight=1)
frame.columnconfigure(3, weight=1)
frame.columnconfigure(4, weight=1)

root.mainloop()

