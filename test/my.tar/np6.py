import os
import json
import dns.resolver
import requests
import base64
import threading
import subprocess
from datetime import datetime
from cryptography import x509
from cryptography.hazmat.backends import default_backend
import tkinter as tk
from tkinter import ttk
import pygame

# Styling configurations
NORD_STYLES = {
    "standard": {
        "background": "#2E3440",
        "foreground": "#D8DEE9",
        "highlight": "#88C0D0",
        "error": "#BF616A",
        "header": "#4C566A",
        "row_odd": "#3B4252",
        "row_even": "#434C5E",
        "button": "#5E81AC",
        "invert_button": "#BF616A"
    },
    "frost": {
        "background": "#8FBCBB",
        "foreground": "#2E3440",
        "highlight": "#88C0D0",
        "error": "#BF616A",
        "header": "#4C566A",
        "row_odd": "#A3BE8C",
        "row_even": "#EBCB8B",
        "button": "#5E81AC",
        "invert_button": "#D08770"
    },
    "aurora": {
        "background": "#A3BE8C",
        "foreground": "#2E3440",
        "highlight": "#88C0D0",
        "error": "#BF616A",
        "header": "#4C566A",
        "row_odd": "#B48EAD",
        "row_even": "#D08770",
        "button": "#5E81AC",
        "invert_button": "#88C0D0"
    }
}

REGION_MAPPINGS = {
    "prod0": "eu-west-1",
    "prod1": "eu-west-2",
    "qa0": "eu-west",
    "qa1": "eu-east",
    "qa3": "ca-central",
    "qa4": "eu-central1"
}

def apply_theme(theme):
    style = ttk.Style()
    colors = NORD_STYLES[theme]
    style.configure("TFrame", background=colors["background"])
    style.configure("TLabelFrame", background=colors["background"], foreground=colors["foreground"])
    style.configure("Treeview", background=colors["background"], foreground=colors["foreground"], fieldbackground=colors["background"])
    style.configure("Treeview.Heading", background=colors["header"], foreground=colors["foreground"])
    style.configure("TButton", background=colors["button"], foreground=colors["foreground"])
    style.map("TButton", background=[("active", colors["highlight"])])
    style.configure("TEntry", background=colors["background"], foreground=colors["foreground"], fieldbackground=colors["background"])
    style.configure("Invert.TButton", background=colors["invert_button"], foreground=colors["foreground"])
    style.map("Invert.TButton", background=[("active", colors["highlight"])])

def play_audio():
    pygame.mixer.init()
    pygame.mixer.music.load("https://storage.googleapis.com/soundboards/Cartoons/THE%20SIMPSONS/MR%20BURNS/MP3/EXCELLENT%20-%20AUDIO%20FROM%20JAYUZUMI.COM.mp3")
    pygame.mixer.music.play()

class NSLookup:
    def __init__(self, master, style):
        self.master = master
        self.style = style
        self.is_collapsed = False
        self.setup_ui()
        self.domains = self.load_domains()
        self.update_nslookup_table()

    def setup_ui(self):
        self.frame = ttk.LabelFrame(self.master, text="NSLookup", padding="10")
        self.frame.grid(row=1, column=0, sticky="nsew")

        self.table_title_frame = ttk.Frame(self.frame)
        self.table_title_frame.grid(row=0, column=0, columnspan=4, sticky="ew")
        ttk.Label(self.table_title_frame, text="NSLookup").pack(side=tk.LEFT)

        self.collapse_btn = ttk.Button(self.table_title_frame, text="Collapse", command=self.toggle_collapse, style="Invert.TButton")
        self.collapse_btn.pack(side=tk.RIGHT, padx=5)

        self.domain_entry = ttk.Entry(self.frame, width=50)
        self.domain_entry.grid(row=1, column=0, padx=5, pady=5)
        
        self.add_domain_btn = ttk.Button(self.frame, text="Add Domain", command=self.add_domain)
        self.add_domain_btn.grid(row=1, column=1, padx=5, pady=5)

        self.refresh_btn = ttk.Button(self.frame, text="Refresh", command=self.update_nslookup_table)
        self.refresh_btn.grid(row=1, column=2, padx=5, pady=5)

        self.reset_btn = ttk.Button(self.frame, text="Reset Domains", command=self.reset_domains)
        self.reset_btn.grid(row=1, column=3, padx=5, pady=5)
        
        self.table = self.setup_table(self.frame, ("Domain", "Name", "IP Address", "Region", "Timestamp"))
        self.table.grid(row=2, column=0, columnspan=4, padx=5, pady=5, sticky="nsew")

        self.scrollbar_y = ttk.Scrollbar(self.frame, orient=tk.VERTICAL, command=self.table.yview)
        self.table.configure(yscroll=self.scrollbar_y.set)
        self.scrollbar_y.grid(row=2, column=4, sticky='ns')

        self.frame.rowconfigure(2, weight=1)
        self.frame.columnconfigure(0, weight=1)

    def toggle_collapse(self):
        if self.is_collapsed:
            self.table.grid()
            self.scrollbar_y.grid()
            self.domain_entry.grid()
            self.add_domain_btn.grid()
            self.refresh_btn.grid()
            self.reset_btn.grid()
            self.collapse_btn.config(text="Collapse")
        else:
            self.table.grid_remove()
            self.scrollbar_y.grid_remove()
            self.domain_entry.grid_remove()
            self.add_domain_btn.grid_remove()
            self.refresh_btn.grid_remove()
            self.reset_btn.grid_remove()
            self.collapse_btn.config(text="Expand")
        self.is_collapsed = not self.is_collapsed
    
    def load_domains(self):
        try:
            with open("nslookup.json", "r") as file:
                return json.load(file)
        except FileNotFoundError:
            return ["google.com", "yahoo.com", "mail.com", "dogpile.com"]
    
    def save_domains(self):
        with open("nslookup.json", "w") as file:
            json.dump(self.domains, file)
    
    def add_domain(self):
        domain = self.domain_entry.get().strip()
        if domain:
            self.domains.append(domain)
            self.save_domains()
            self.update_nslookup_table()
    
    def reset_domains(self):
        self.domains = ["google.com", "yahoo.com", "mail.com", "dogpile.com"]
        self.save_domains()
        self.update_nslookup_table()
    
    def update_nslookup_table(self):
        self.clear_table(self.table)
        resolver = dns.resolver.Resolver()
        for domain in self.domains:
            try:
                answer = resolver.resolve(domain, 'A')
                for rdata in answer:
                    region = REGION_MAPPINGS.get(domain.split('.')[0], "unknown")
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    self.table.insert("", "end", values=(domain, rdata, rdata.address, region, timestamp))
            except Exception as e:
                print(f"Error resolving {domain}: {e}")
        self.master.after(600000, self.update_nslookup_table)  # Auto-refresh every 10 minutes

    def setup_table(self, master, columns):
        table = ttk.Treeview(master, columns=columns, show="headings")
        for col in columns:
            table.heading(col, text=col)
            table.column(col, anchor=tk.W, width=150)
        return table

    def clear_table(self, table):
        for item in table.get_children():
            table.delete(item)

class HTTPRequest:
    def __init__(self, master, style):
        self.master = master
        self.style = style
        self.is_collapsed = False
        self.setup_ui()

        self.urls = self.load_urls()
        self.update_http_table()

    def setup_ui(self):
        self.frame = ttk.LabelFrame(self.master, text="HTTPRequest", padding="10")
        self.frame.grid(row=2, column=0, sticky="nsew")

        self.table_title_frame = ttk.Frame(self.frame)
        self.table_title_frame.grid(row=0, column=0, columnspan=4, sticky="ew")
        ttk.Label(self.table_title_frame, text="HTTPRequest").pack(side=tk.LEFT)

        self.collapse_btn = ttk.Button(self.table_title_frame, text="Collapse", command=self.toggle_collapse, style="Invert.TButton")
        self.collapse_btn.pack(side=tk.RIGHT, padx=5)

        self.url_entry = ttk.Entry(self.frame, width=50)
        self.url_entry.grid(row=1, column=0, padx=5, pady=5)
        
        self.add_url_btn = ttk.Button(self.frame, text="Add URL", command=self.add_url)
        self.add_url_btn.grid(row=1, column=1, padx=5, pady=5)

        self.refresh_btn = ttk.Button(self.frame, text="Refresh", command=self.update_http_table)
        self.refresh_btn.grid(row=1, column=2, padx=5, pady=5)

        self.reset_btn = ttk.Button(self.frame, text="Reset URLs", command=self.reset_urls)
        self.reset_btn.grid(row=1, column=3, padx=5, pady=5)
        
        self.table = self.setup_table(self.frame, ("URL", "Status Code", "Status Text", "Timestamp"))
        self.table.grid(row=2, column=0, columnspan=4, padx=5, pady=5, sticky="nsew")

        self.scrollbar_y = ttk.Scrollbar(self.frame, orient=tk.VERTICAL, command=self.table.yview)
        self.table.configure(yscroll=self.scrollbar_y.set)
        self.scrollbar_y.grid(row=2, column=4, sticky='ns')

        self.frame.rowconfigure(2, weight=1)
        self.frame.columnconfigure(0, weight=1)

    def toggle_collapse(self):
        if self.is_collapsed:
            self.table.grid()
            self.scrollbar_y.grid()
            self.url_entry.grid()
            self.add_url_btn.grid()
            self.refresh_btn.grid()
            self.reset_btn.grid()
            self.collapse_btn.config(text="Collapse")
        else:
            self.table.grid_remove()
            self.scrollbar_y.grid_remove()
            self.url_entry.grid_remove()
            self.add_url_btn.grid_remove()
            self.refresh_btn.grid_remove()
            self.reset_btn.grid_remove()
            self.collapse_btn.config(text="Expand")
        self.is_collapsed = not self.is_collapsed

    def load_urls(self):
        try:
            with open("urls.json", "r") as file:
                return json.load(file)
        except FileNotFoundError:
            return ["https://status.cloud.google.com", "https://portal.office.com"]

    def save_urls(self):
        with open("urls.json", "w") as file:
            json.dump(self.urls, file)

    def add_url(self):
        url = self.url_entry.get().strip()
        if url:
            self.urls.append(url)
            self.save_urls()
            self.update_http_table()

    def reset_urls(self):
        self.urls = ["https://status.cloud.google.com", "https://portal.office.com"]
        self.save_urls()
        self.update_http_table()

    def update_http_table(self):
        self.clear_table(self.table)
        for url in self.urls:
            try:
                response = requests.get(url)
                status_text = response.text
                if "we’re all good" in status_text:
                    status_text = "We’re all good"
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                self.table.insert("", "end", values=(url, response.status_code, status_text, timestamp))
            except Exception as e:
                print(f"Error fetching {url}: {e}")
        self.master.after(600000, self.update_http_table)  # Auto-refresh every 10 minutes

    def setup_table(self, master, columns):
        table = ttk.Treeview(master, columns=columns, show="headings")
        for col in columns:
            table.heading(col, text=col)
            table.column(col, anchor=tk.W, width=150)
        return table

    def clear_table(self, table):
        for item in table.get_children():
            table.delete(item)

class JWKSCheck:
    def __init__(self, master, style):
        self.master = master
        self.style = style
        self.is_collapsed = False
        self.setup_ui()

        self.default_url = "https://auth.pingone.com/0a7af83d-4ed9-4510-93cd-506fe835f69a/as/jwks"
        self.url = self.default_url
        self.update_jwks_table()

    def setup_ui(self):
        self.frame = ttk.LabelFrame(self.master, text="JWKSCheck", padding="10")
        self.frame.grid(row=3, column=0, sticky="nsew")

        self.table_title_frame = ttk.Frame(self.frame)
        self.table_title_frame.grid(row=0, column=0, columnspan=4, sticky="ew")
        ttk.Label(self.table_title_frame, text="JWKSCheck").pack(side=tk.LEFT)

        self.collapse_btn = ttk.Button(self.table_title_frame, text="Collapse", command=self.toggle_collapse, style="Invert.TButton")
        self.collapse_btn.pack(side=tk.RIGHT, padx=5)

        self.url_entry = ttk.Entry(self.frame, width=50)
#        self.url_entry.insert(0, self.default_url)
        self.url_entry.insert(0, "https://auth.pingone.com/0a7af83d-4ed9-4510-93cd-506fe835f69a/as/jwks")
        self.url_entry.grid(row=1, column=0, padx=5, pady=5)
        
        self.add_url_btn = ttk.Button(self.frame, text="Set URL", command=self.set_url)
        self.add_url_btn.grid(row=1, column=1, padx=5, pady=5)

        self.refresh_btn = ttk.Button(self.frame, text="Refresh", command=self.update_jwks_table)
        self.refresh_btn.grid(row=1, column=2, padx=5, pady=5)
        
        self.cert_table = self.setup_table(self.frame, ("Key ID", "Name", "Not Valid Before", "Not Valid After"))
        self.cert_table.grid(row=2, column=0, columnspan=4, padx=5, pady=5, sticky="nsew")

        self.cert_scrollbar_y = ttk.Scrollbar(self.frame, orient=tk.VERTICAL, command=self.cert_table.yview)
        self.cert_table.configure(yscroll=self.cert_scrollbar_y.set)
        self.cert_scrollbar_y.grid(row=2, column=4, sticky='ns')

        self.ec_table = self.setup_table(self.frame, ("Key Type", "Key ID", "Use", "X", "Y", "Curve"))
        self.ec_table.grid(row=3, column=0, columnspan=4, padx=5, pady=5, sticky="nsew")

        self.ec_scrollbar_y = ttk.Scrollbar(self.frame, orient=tk.VERTICAL, command=self.ec_table.yview)
        self.ec_table.configure(yscroll=self.ec_scrollbar_y.set)
        self.ec_scrollbar_y.grid(row=3, column=4, sticky='ns')

        self.frame.rowconfigure(2, weight=1)
        self.frame.columnconfigure(0, weight=1)

    def toggle_collapse(self):
        if self.is_collapsed:
            self.cert_table.grid()
            self.cert_scrollbar_y.grid()
            self.ec_table.grid()
            self.ec_scrollbar_y.grid()
            self.url_entry.grid()
            self.add_url_btn.grid()
            self.refresh_btn.grid()
            self.collapse_btn.config(text="Collapse")
        else:
            self.cert_table.grid_remove()
            self.cert_scrollbar_y.grid_remove()
            self.ec_table.grid_remove()
            self.ec_scrollbar_y.grid_remove()
            self.url_entry.grid_remove()
            self.add_url_btn.grid_remove()
            self.refresh_btn.grid_remove()
            self.collapse_btn.config(text="Expand")
        self.is_collapsed = not self.is_collapsed
    
    def set_url(self):
        self.url = self.url_entry.get().strip()
        if not self.url:
            self.url = self.default_url
        self.update_jwks_table()
    
    def update_jwks_table(self):
        self.clear_table(self.cert_table)
        self.clear_table(self.ec_table)
        try:
            response = requests.get(self.url)
            response.raise_for_status()
            jwks = response.json()
            for key in jwks.get('keys', []):
                if 'x5c' in key:
                    for cert in key['x5c']:
                        cert_bytes = base64.b64decode(cert)
                        x509_cert = x509.load_der_x509_certificate(cert_bytes, default_backend())
                        key_id = key['kid']
                        name = x509_cert.subject
                        not_valid_before = x509_cert.not_valid_before
                        not_valid_after = x509_cert.not_valid_after
                        self.cert_table.insert("", "end", values=(key_id, name, not_valid_before, not_valid_after))
                if key['kty'] == 'EC':
                    key_type = key['kty']
                    key_id = key['kid']
                    use = key['use']
                    x = key.get('x', '')
                    y = key.get('y', '')
                    curve = key.get('crv', '')
                    self.ec_table.insert("", "end", values=(key_type, key_id, use, x, y, curve))
        except Exception as e:
            print(f"Error fetching JWKS: {e}")
        self.master.after(600000, self.update_jwks_table)  # Auto-refresh every 10 minutes
    
    def setup_table(self, master, columns):
        table = ttk.Treeview(master, columns=columns, show="headings")
        for col in columns:
            table.heading(col, text=col)
            table.column(col, anchor=tk.W, width=150)
        return table

    def clear_table(self, table):
        for item in table.get_children():
            table.delete(item)

def create_errors_file():
    file_name = 'errors.json'
    if not os.path.exists(file_name):
        with open(file_name, 'w') as file:
            json.dump([], file)
        print(f"{file_name} created.")
    else:
        print(f"{file_name} already exists.")

def open_ping_window(theme):
    ping_window = tk.Toplevel()
    ping_window.title("Ping Tool")
    ping_window.geometry("400x300")

    style = ttk.Style(ping_window)
    colors = NORD_STYLES[theme.get()]
    style.configure("TFrame", background=colors["background"])
    style.configure("TLabel", background=colors["background"], foreground=colors["foreground"])
    style.configure("TButton", background=colors["button"], foreground=colors["foreground"])
    style.map("TButton", background=[("active", colors["highlight"])])
    style.configure("TEntry", background=colors["background"], foreground=colors["foreground"], fieldbackground=colors["background"])

    frame = ttk.Frame(ping_window, padding="10")
    frame.pack(fill=tk.BOTH, expand=True)

    ttk.Label(frame, text="Enter Hostname/IP:").pack(padx=5, pady=5)
    ping_entry = ttk.Entry(frame, width=30)
    ping_entry.pack(padx=5, pady=5)

    result_text = tk.Text(frame, wrap=tk.WORD, height=10, width=40, bg=colors["background"], fg=colors["foreground"])
    result_text.pack(padx=5, pady=5)

    def ping_host():
        host = ping_entry.get().strip()
        if host:
            result_text.delete(1.0, tk.END)
            try:
                output = subprocess.check_output(["ping", "-c", "4", host], stderr=subprocess.STDOUT, universal_newlines=True)
                result_text.insert(tk.END, output)
            except subprocess.CalledProcessError as e:
                result_text.insert(tk.END, e.output)

    ttk.Button(frame, text="Ping", command=ping_host).pack(padx=5, pady=5)
    ttk.Button(frame, text="Close", command=ping_window.destroy).pack(padx=5, pady=5)

def main():
    create_errors_file()

    root = tk.Tk()
    root.title("Network Tools")
    root.geometry("1100x700")

    top_frame = ttk.Frame(root, padding="5")
    top_frame.grid(row=0, column=0, columnspan=2, sticky="ew")
    ttk.Button(top_frame, text="Play Audio", command=play_audio).pack(side=tk.LEFT, padx=5, pady=5)

    for i in range(4):
        root.rowconfigure(i + 1, weight=1)
    root.columnconfigure(0, weight=1)
    root.columnconfigure(1, weight=0)

    theme_var = tk.StringVar(value="standard")
    
    # Sidebar for theme selection
    sidebar = ttk.Frame(root, padding="5")
    sidebar.grid(row=1, column=1, rowspan=4, sticky="ns")
    
    ttk.Label(sidebar, text="Choose Theme:").grid(row=0, column=0, padx=5, pady=5)
    ttk.Radiobutton(sidebar, text="Nord", variable=theme_var, value="standard", command=lambda: apply_theme(theme_var.get())).grid(row=1, column=0, padx=5, pady=5)
    ttk.Radiobutton(sidebar, text="Frost", variable=theme_var, value="frost", command=lambda: apply_theme(theme_var.get())).grid(row=2, column=0, padx=5, pady=5)
    ttk.Radiobutton(sidebar, text="Aurora", variable=theme_var, value="aurora", command=lambda: apply_theme(theme_var.get())).grid(row=3, column=0, padx=5, pady=5)
    ttk.Button(sidebar, text="Open Ping Tool", command=lambda: open_ping_window(theme_var)).grid(row=4, column=0, padx=5, pady=5)

    nslookup = NSLookup(root, theme_var)
    http_request = HTTPRequest(root, theme_var)
    jwks_check = JWKSCheck(root, theme_var)

    apply_theme(theme_var.get())
    root.mainloop()

if __name__ == "__main__":
    main()

