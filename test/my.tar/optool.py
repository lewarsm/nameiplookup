import tkinter as tk

from tkinter import ttk, messagebox

import re

import subprocess

import json

import requests

from requests.packages.urllib3.exceptions import InsecureRequestWarning

import time

from datetime import datetime

import threading

import dns.resolver

import warnings

from cryptography import x509

from cryptography.hazmat.backends import default_backend

 

#Silence Self Signed Certificate Errors

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

warnings.filterwarnings("ignore")

 

# Nord color scheme

nord_colors = {

    'background': '#2E3440',

    'foreground': '#D8DEE9',

    'highlight': '#88C0D0',

    'error': '#BF616A',

    'header': '#4C566A',

    'row_odd': '#3B4252',

    'row_even': '#434C5E',

    'button': '#5E81AC'

}

 

# Hanger mappings

hanger_mappings = {

    'prod0': 'hanger0',

    'prod1': 'hanger1',

    'qa0': 'hanger0',

    'qa1': 'hanger1',

    'dev0': 'hanger0',

    'dev1': 'hanger1'

}

 

DEBUG=False

 

class ErrorManager:

    def __init__(self, file_name='errors.json'):

        self.file_name = file_name

        self.errors = self.load_errors()

 

    def load_errors(self):

        with open(self.file_name, 'r') as file:

            return json.load(file)['errors']

 

    def save_errors(self):

        with open(self.file_name, 'w') as file:

            json.dump({"errors": self.errors}, file, indent=4)

 

    def add_error(self, error_message):

        self.errors.append(error_message)

        self.save_errors()

 

    def display_errors(self):

        if self.errors:

            error_message = "\n".join(self.errors)

            if DEBUG:

                messagebox.showerror("Error", error_message, icon='error')

            else:

                pass

            self.save_errors()

            self.errors.clear()

 

class NSLookup:

    def __init__(self, parent, error_manager):

        self.parent = parent

        self.error_manager = error_manager

#        self.domains = json.loads('{"domains": ["sso.fed.prod.aws.swalife.com", "sso.fed.prod.aws.swacorp.com", "sso.fed.qa.aws.swalife.com", "sso.fed.qa.aws.swacorp.com", "sso.fed.dev.aws.swalife.com", "sso.fed.dev.aws.swacorp.com", "sso.cfi.prod.aws.southwest.com" ]}')

        self.domains = self.load_domains()

        self.create_widgets()

        self.update_table()

 

    def load_domains(self):

         with open ('domains.json','r') as file:

            return json.load(file)

 

    def save_domains(self):

         with open ('domains.json','w') as file:

            json.dump(self.domains, file, indent=4)

 

    def create_widgets(self):

        self.frame = ttk.Frame(self.parent)

        self.frame.pack(fill=tk.BOTH, expand=True)

        # Create vertical and horizontal scrollbars

        self.table_scroll_y = ttk.Scrollbar(self.frame, orient=tk.VERTICAL)

        self.table_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)

        self.table_scroll_x = ttk.Scrollbar(self.frame, orient=tk.HORIZONTAL)

        self.table_scroll_x.pack(side=tk.BOTTOM, fill=tk.X)

 

        self.table = ttk.Treeview(self.frame, columns=('Domain', 'Name', 'IP Address', 'Hanger', 'Timestamp'), show='headings',yscrollcommand=self.table_scroll_y.set,xscrollcommand=self.table_scroll_x.set)

        self.table.heading('Domain', text='Domain')

        self.table.heading('Name', text='Name')

        self.table.heading('IP Address', text='IP Address')

        self.table.heading('Hanger', text='Hanger')

        self.table.heading('Timestamp', text='Timestamp')

        self.table.pack(fill=tk.BOTH, expand=True)

       # Configure scrollbars

        self.table_scroll_y.config(command=self.table.yview)

        self.table_scroll_x.config(command=self.table.xview)

        self.table.bind('<Double-1>', self.delete_row)

 

        self.add_domain_entry = ttk.Entry(self.frame)

        self.add_domain_entry.pack(side=tk.LEFT, padx=5, pady=5)

 

        self.add_domain_button = ttk.Button(self.frame, text='Add Domain', command=self.add_domain)

        self.add_domain_button.pack(side=tk.LEFT, padx=5, pady=5)

 

        self.update_button = ttk.Button(self.frame, text='Update', command=self.update_table)

        self.update_button.pack(side=tk.RIGHT, padx=5, pady=5)

 

    def add_domain(self):

        domain = self.add_domain_entry.get()

        if domain:

            self.domains['domains'].append(domain)

            self.add_domain_entry.delete(0, tk.END)

            self.save_domains()

            self.update_table()

 

    def update_table(self):

        for row in self.table.get_children():

            self.table.delete(row)

        for domain in self.domains['domains']:

            result = self.nslookup(domain)

            if result:

                self.table.insert('', tk.END, values=result)

            self.error_manager.display_errors()

 

    def nslookup(self, domain):

        try:

            answers = dns.resolver.resolve(domain, 'A')

            names = dns.resolver.resolve(domain, 'CNAME')

            name = names[0].to_text()

            ip_address = answers[0].to_text()

            hanger = self.get_hanger(name)

            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            return (domain, name, ip_address, hanger, timestamp)

        except Exception as e:

            self.error_manager.add_error(f'Failed to lookup {domain}: {e}')

            return None

 

    def get_hanger(self, name):

        for key, value in hanger_mappings.items():

            if key in name:

                return value

        return 'Unknown'

 

    def delete_row(self, event):

        selected_item = self.table.selection()[0]

        domain = self.table.item(selected_item)['values'][0]

        self.domains['domains'].remove(domain)

        self.save_domains()

        self.table.delete(selected_item)

 

class HTTPRequest:

    def __init__(self, parent, error_manager):

        self.parent = parent

        self.error_manager = error_manager

#        self.sites = ['sso.fed.prod.aws.swacorp.com/pf/heartbeat.ping', 'sso.fed.prod.aws.swalife.com/pf/heartbeat.ping', 'sso.fed.qa.aws.swacorp.com/pf/heartbeat.ping', 'sso.fed.qa.aws.swalife.com/pf/heartbeat.ping', 'sso.fed.dev.aws.swacorp.com/pf/heartbeat.ping', 'sso.fed.dev.aws.swalife.com/pf/heartbeat.ping']

        self.sites = self.load_sites()

        self.create_widgets()

        self.update_table()

 

    def load_sites(self):

         with open ('sites.json','r') as file:

            return json.load(file)

 

    def save_sites(self):

         with open ('sites.json','w') as file:

            json.dump(self.sites, file, indent=4)

 

    def create_widgets(self):

        self.frame = ttk.Frame(self.parent)

        self.frame.pack(fill=tk.BOTH, expand=True)

        # Create vertical and horizontal scrollbars

        self.table_scroll_y = ttk.Scrollbar(self.frame, orient=tk.VERTICAL)

        self.table_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)

        self.table_scroll_x = ttk.Scrollbar(self.frame, orient=tk.HORIZONTAL)

        self.table_scroll_x.pack(side=tk.BOTTOM, fill=tk.X)

 

        self.table = ttk.Treeview(self.frame, columns=('Site', 'HTTP Code', 'Message'), show='headings',yscrollcommand=self.table_scroll_y.set,xscrollcommand=self.table_scroll_x.set)

        self.table.heading('Site', text='Site')

        self.table.heading('HTTP Code', text='HTTP Code')

        self.table.heading('Message', text='Message')

        self.table.pack(fill=tk.BOTH, expand=True)

       # Configure scrollbars

        self.table_scroll_y.config(command=self.table.yview)

        self.table_scroll_x.config(command=self.table.xview)

        self.table.bind('<Double-1>', self.delete_row)

 

        self.add_site_entry = ttk.Entry(self.frame)

        self.add_site_entry.pack(side=tk.LEFT, padx=5, pady=5)

 

        self.add_site_button = ttk.Button(self.frame, text='Add Site', command=self.add_site)

        self.add_site_button.pack(side=tk.LEFT, padx=5, pady=5)

 

        self.update_button = ttk.Button(self.frame, text='Update', command=self.update_table)

        self.update_button.pack(side=tk.RIGHT, padx=5, pady=5)

 

    def add_site(self):

        site = self.add_site_entry.get()

        if site:

            self.sites['sites'].append(site)

            self.add_site_entry.delete(0, tk.END)

            self.save_sites()

            self.update_table()

 

    def update_table(self):

        for row in self.table.get_children():

            self.table.delete(row)

        for site in self.sites['sites']:

            result = self.http_request(site)

            if result:

                self.table.insert('', tk.END, values=result)

        self.error_manager.display_errors()

 

    def http_request(self, site):

        try:

            response = requests.get(f'https://{site}', verify=False)

            message = 'OK' if 'OK' in response.text else 'Invalid Response'

            return (site, response.status_code, message)

        except Exception as e:

            self.error_manager.add_error(f'Failed to request {site}: {e}')

            return None

 

    def delete_row(self, event):

        selected_item = self.table.selection()[0]

        site = self.table.item(selected_item)['values'][0]

        self.sites['sites'].remove(site)

        self.save_sites()

        self.table.delete(selected_item)

 

class JWKS:

    def __init__(self, parent, error_manager):

        self.parent = parent

        self.error_manager = error_manager

        self.url = 'https://auth.pingone.com/0a7af83d-4ed9-4510-93cd-506fe835f69a/as/jwks'

        self.create_widgets()

        self.update_table()

 

    def create_widgets(self):

        self.frame = ttk.Frame(self.parent)

        self.frame.pack(fill=tk.BOTH, expand=True)

        # Create vertical and horizontal scrollbars

        self.table_scroll_y = ttk.Scrollbar(self.frame, orient=tk.VERTICAL)

        self.table_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)

        self.table_scroll_x = ttk.Scrollbar(self.frame, orient=tk.HORIZONTAL)

        self.table_scroll_x.pack(side=tk.BOTTOM, fill=tk.X)

 

        self.table = ttk.Treeview(self.frame, columns=('Name', 'Key ID', 'Creation Date', 'Expiration Date'), show='headings',yscrollcommand=self.table_scroll_y.set,xscrollcommand=self.table_scroll_x.set)

        self.table.heading('Name', text='Name')

        self.table.heading('Key ID', text='Key ID')

        self.table.heading('Creation Date', text='Creation Date')

        self.table.heading('Expiration Date', text='Expiration Date')

        self.table.pack(fill=tk.BOTH, expand=True)

       # Configure scrollbars

        self.table_scroll_y.config(command=self.table.yview)

        self.table_scroll_x.config(command=self.table.xview)

 

        self.url_entry = ttk.Entry(self.frame)

        self.url_entry.pack(side=tk.LEFT, padx=5, pady=5)

        self.url_entry.insert(0, self.url)

 

        self.update_button = ttk.Button(self.frame, text='Update', command=self.update_table)

        self.update_button.pack(side=tk.RIGHT, padx=5, pady=5)

 

    def update_table(self):

        for row in self.table.get_children():

            self.table.delete(row)

        self.url = self.url_entry.get()

        keys = self.get_jwks_keys(self.url)

        for key in keys:

            self.table.insert('', tk.END, values=key)

        self.error_manager.display_errors()

 

    def get_jwks_keys(self, url):

        try:

            response = requests.get(url,verify=False)

            jwks = response.json()

            keys = []

            for key in jwks['keys']:

                key_id = key['kid']

                cert = key['x5c'][0]

                x509_cert = x509.load_pem_x509_certificate(f'-----BEGIN CERTIFICATE-----\n{cert}\n-----END CERTIFICATE-----'.encode(), default_backend())

                creation_date = x509_cert.not_valid_before_utc.strftime('%Y-%m-%d %H:%M:%S')

                subject = x509_cert.subject.rfc4514_string()[:60]

                expiration_date = x509_cert.not_valid_after_utc.strftime('%Y-%m-%d %H:%M:%S')

                keys.append((subject, key_id, creation_date, expiration_date))

            return keys

        except Exception as e:

            self.error_manager.add_error(f'Failed to get JWKS keys: {e}')

            return []

 

class App:

    def __init__(self, root):

        self.root = root

        self.root.title('Network Tools')

        self.root.configure(bg=nord_colors['background'])

 

        self.error_manager = ErrorManager()

 

        self.toolbar = tk.Frame(self.root, bg=nord_colors['header'])

        self.toolbar.pack(side=tk.TOP, fill=tk.X)

 

        self.help_button = tk.Button(self.toolbar, text='Help', command=self.show_help, bg=nord_colors['button'], fg=nord_colors['foreground'])

        self.help_button.pack(side=tk.RIGHT, padx=5, pady=5)

 

        self.restore_button = tk.Button(self.toolbar, text='Restore Defaults', command=self.restore_defaults, bg=nord_colors['button'], fg=nord_colors['foreground'])

        self.restore_button.pack(side=tk.RIGHT, padx=5, pady=5)

 

        self.nslookup = NSLookup(self.root, self.error_manager)

        self.http_request = HTTPRequest(self.root, self.error_manager)

        self.jwks = JWKS(self.root, self.error_manager)

 

        self.auto_update()

 

    def show_help(self):

        with open('help.json', 'r') as file:

            help_content = json.load(file)['help']

        help_window = tk.Toplevel(self.root)

        help_window.title('Help')

        help_window.configure(bg=nord_colors['background'])

        help_label = tk.Label(help_window, text=help_content, bg=nord_colors['background'], fg=nord_colors['foreground'], wraplength=400)

        help_label.pack(padx=10, pady=10)

        close_button = tk.Button(help_window, text='Close', command=help_window.destroy, bg=nord_colors['button'], fg=nord_colors['foreground'])

        close_button.pack(pady=5)

 

    def restore_defaults(self):

        with open('domains.json', 'w') as file:

            json.dump({"domains": ["sso.fed.prod.aws.swalife.com", "sso.fed.prod.aws.swacorp.com", "sso.fed.qa.aws.swalife.com", "sso.fed.qa.aws.swacorp.com", "sso.fed.dev.aws.swalife.com", "sso.fed.dev.aws.swacorp.com", "sso.cfi.prod.aws.southwest.com"]}, file, indent=4)

        with open('sites.json', 'w') as file:

            json.dump({"sites": ["sso.fed.prod.aws.swacorp.com/pf/heartbeat.ping", "sso.fed.prod.aws.swalife.com/pf/heartbeat.ping", "sso.fed.qa.aws.swacorp.com/pf/heartbeat.ping", "sso.fed.qa.aws.swalife.com/pf/heartbeat.ping", "sso.fed.dev.aws.swacorp.com/pf/heartbeat.ping", "sso.fed.dev.aws.swalife.com/pf/heartbeat.ping"]}, file, indent=4)

        self.nslookup.domains = self.nslookup.load_domains()

        self.http_request.sites = self.http_request.load_sites()

        self.nslookup.update_table()

        self.http_request.update_table()

 

    def auto_update(self):

        self.nslookup.update_table()

        self.http_request.update_table()

        self.jwks.update_table()

        self.root.after(600000, self.auto_update)  # Update every 10 minutes

 

if __name__ == '__main__':

    root = tk.Tk()

    app = App(root)

    root.mainloop()
