import os
import json
import dns.resolver
import requests
import base64
import threading
import subprocess
from datetime import datetime
from cryptography import x509
from cryptography.hazmat.backends import default_backend
import tkinter as tk
from tkinter import ttk
from pythonping import ping
import pygame
from PIL import Image, ImageTk
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import warnings

#Silence Self Signed Certificate Errors
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
warnings.filterwarnings("ignore")

# Styling configurations
NORD_STYLES = {
    "standard": {
        "background": "#2E3440",
        "foreground": "#D8DEE9",
        "highlight": "#88C0D0",
        "error": "#BF616A",
        "header": "#4C566A",
        "row_odd": "#3B4252",
        "row_even": "#434C5E",
        "button": "#5E81AC",
        "invert_button": "#BF616A"
    },
    "frost": {
        "background": "#8FBCBB",
        "foreground": "#2E3440",
        "highlight": "#88C0D0",
        "error": "#BF616A",
        "header": "#4C566A",
        "row_odd": "#A3BE8C",
        "row_even": "#EBCB8B",
        "button": "#5E81AC",
        "invert_button": "#D08770"
    },
    "aurora": {
        "background": "#A3BE8C",
        "foreground": "#2E3440",
        "highlight": "#88C0D0",
        "error": "#BF616A",
        "header": "#4C566A",
        "row_odd": "#B48EAD",
        "row_even": "#D08770",
        "button": "#5E81AC",
        "invert_button": "#88C0D0"
    }
}

REGION_MAPPINGS = {
    "prod0": "eu-west-1",
    "prod1": "eu-west-2",
    "qa0": "eu-west",
    "qa1": "eu-east",
    "qa3": "ca-central",
    "qa4": "eu-central1"
}

def apply_theme(theme):
    style = ttk.Style()
    colors = NORD_STYLES[theme]
    style.configure("TFrame", background=colors["background"])
    style.configure("TLabelFrame", background=colors["background"], foreground=colors["foreground"])
    style.configure("Treeview", background=colors["background"], foreground=colors["foreground"], fieldbackground=colors["background"])
    style.configure("Treeview.Heading", background=colors["header"], foreground=colors["foreground"])
    style.configure("TButton", background=colors["button"], foreground=colors["foreground"])
    style.map("TButton", background=[("active", colors["highlight"])])
    style.configure("TEntry", background=colors["background"], foreground=colors["foreground"], fieldbackground=colors["background"])
    style.configure("Invert.TButton", background=colors["invert_button"], foreground=colors["foreground"])
    style.map("Invert.TButton", background=[("active", colors["highlight"])])

def play_audio():
    pygame.mixer.init()
    pygame.mixer.music.load("https://storage.googleapis.com/soundboards/Cartoons/THE%20SIMPSONS/MR%20BURNS/MP3/EXCELLENT%20-%20AUDIO%20FROM%20JAYUZUMI.COM.mp3")
    pygame.mixer.music.play()

def open_jwt_window(theme):
    jwt_window = tk.Toplevel()
    jwt_window.title("JWT Decoder")
    jwt_window.geometry("500x400")

    style = ttk.Style(jwt_window)
    colors = NORD_STYLES[theme.get()]
    style.configure("TFrame", background=colors["background"])
    style.configure("TLabel", background=colors["background"], foreground=colors["foreground"])
    style.configure("TButton", background=colors["button"], foreground=colors["foreground"])
    style.map("TButton", background=[("active", colors["highlight"])])
    style.configure("TEntry", background=colors["background"], foreground=colors["foreground"], fieldbackground=colors["background"])
    style.configure("TText", background=colors["background"], foreground=colors["foreground"])

    frame = ttk.Frame(jwt_window, padding="10")
    frame.pack(fill=tk.BOTH, expand=True)

    ttk.Label(frame, text="Enter JWT:").pack(padx=5, pady=5)
    jwt_entry = ttk.Entry(frame, width=50)
    jwt_entry.pack(padx=5, pady=5)

    result_text = tk.Text(frame, wrap=tk.WORD, height=10, width=40, bg=colors["background"], fg=colors["foreground"])
    result_text.pack(padx=5, pady=5)

    def decode_jwt():
        jwt_token = jwt_entry.get().strip()
        try:
            header, payload, signature = jwt_token.split('.')
            decoded_header = base64.urlsafe_b64decode(header + '==').decode('utf-8')
            decoded_payload = base64.urlsafe_b64decode(payload + '==').decode('utf-8')
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, f"Header:\n{decoded_header}\n\nPayload:\n{decoded_payload}\n\nSignature:\n{signature}")
        except Exception as e:
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, f"Error decoding JWT: {e}")

    ttk.Button(frame, text="Decode", command=decode_jwt).pack(padx=5, pady=5)
    ttk.Button(frame, text="Close", command=jwt_window.destroy).pack(padx=5, pady=5)

def open_saml_window(theme):
    saml_window = tk.Toplevel()
    saml_window.title("SAML Decoder")
    saml_window.geometry("500x400")

    style = ttk.Style(saml_window)
    colors = NORD_STYLES[theme.get()]
    style.configure("TFrame", background=colors["background"])
    style.configure("TLabel", background=colors["background"], foreground=colors["foreground"])
    style.configure("TButton", background=colors["button"], foreground=colors["foreground"])
    style.map("TButton", background=[("active", colors["highlight"])])
    style.configure("TEntry", background=colors["background"], foreground=colors["foreground"], fieldbackground=colors["background"])
    style.configure("TText", background=colors["background"], foreground=colors["foreground"])

    frame = ttk.Frame(saml_window, padding="10")
    frame.pack(fill=tk.BOTH, expand=True)

    ttk.Label(frame, text="Enter SAML:").pack(padx=5, pady=5)
    saml_entry = ttk.Entry(frame, width=50)
    saml_entry.pack(padx=5, pady=5)

    result_text = tk.Text(frame, wrap=tk.WORD, height=10, width=40, bg=colors["background"], fg=colors["foreground"])
    result_text.pack(padx=5, pady=5)

    def decode_saml():
        saml_token = saml_entry.get().strip()
        try:
            decoded_saml = base64.b64decode(saml_token).decode('utf-8')
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, decoded_saml)
        except Exception as e:
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, f"Error decoding SAML: {e}")

    ttk.Button(frame, text="Decode", command=decode_saml).pack(padx=5, pady=5)
    ttk.Button(frame, text="Close", command=saml_window.destroy).pack(padx=5, pady=5)

def open_oidc_window(theme):
    oidc_window = tk.Toplevel()
    oidc_window.title("OIDC/OAuth Debugger")
    oidc_window.geometry("600x900")

    style = ttk.Style(oidc_window)
    colors = NORD_STYLES[theme.get()]
    style.configure("TFrame", background=colors["background"])
    style.configure("TLabel", background=colors["background"], foreground=colors["foreground"])
    style.configure("TButton", background=colors["button"], foreground=colors["foreground"])
    style.map("TButton", background=[("active", colors["highlight"])])
    style.configure("TEntry", background=colors["background"], foreground=colors["foreground"], fieldbackground=colors["background"])
    style.configure("TText", background=colors["background"], foreground=colors["foreground"])

    frame = ttk.Frame(oidc_window, padding="10")
    frame.pack(fill=tk.BOTH, expand=True)

    ttk.Label(frame, text="Choose Flow:").pack(padx=5, pady=5)
    flow_var = tk.StringVar(value="OIDC")
    ttk.Radiobutton(frame, text="OIDC", variable=flow_var, value="OIDC").pack(padx=5, pady=5)
    ttk.Radiobutton(frame, text="OAuth", variable=flow_var, value="OAuth").pack(padx=5, pady=5)

    ttk.Label(frame, text="Well-Known Endpoint:").pack(padx=5, pady=5)
    well_known_entry = ttk.Entry(frame, width=50)
    well_known_entry.pack(padx=5, pady=5)

    ttk.Button(frame, text="Fetch Well-Known", command=lambda: fetch_well_known(well_known_entry.get(), result_text)).pack(padx=5, pady=5)

    ttk.Label(frame, text="Client ID:").pack(padx=5, pady=5)
    client_id_entry = ttk.Entry(frame, width=50)
    client_id_entry.pack(padx=5, pady=5)

    ttk.Label(frame, text="Client Secret:").pack(padx=5, pady=5)
    client_secret_entry = ttk.Entry(frame, width=50, show="*")
    client_secret_entry.pack(padx=5, pady=5)

    ttk.Label(frame, text="Redirect URI:").pack(padx=5, pady=5)
    redirect_uri_entry = ttk.Entry(frame, width=50)
    redirect_uri_entry.pack(padx=5, pady=5)

    ttk.Label(frame, text="Authorization Code:").pack(padx=5, pady=5)
    auth_code_entry = ttk.Entry(frame, width=50)
    auth_code_entry.pack(padx=5, pady=5)

    result_text = tk.Text(frame, wrap=tk.WORD, height=10, width=60, bg=colors["background"], fg=colors["foreground"])
    result_text.pack(padx=5, pady=5)

    def fetch_well_known(endpoint, result_text):
        try:
            response = requests.get(endpoint,verify=False)
            response.raise_for_status()
            well_known_data = response.json()
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, json.dumps(well_known_data, indent=4))
        except Exception as e:
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, f"Error fetching well-known endpoint: {e}")

    ttk.Button(frame, text="Get Tokens", command=lambda: get_tokens(
        well_known_entry.get(),
        client_id_entry.get(),
        client_secret_entry.get(),
        redirect_uri_entry.get(),
        auth_code_entry.get(),
        result_text,
        flow_var.get()
    )).pack(padx=5, pady=5)

    ttk.Button(frame, text="Close", command=oidc_window.destroy).pack(padx=5, pady=5)

def get_tokens(well_known_url, client_id, client_secret, redirect_uri, auth_code, result_text, flow):
    try:
        well_known_response = requests.get(well_known_url,verify=False)
        well_known_response.raise_for_status()
        well_known_data = well_known_response.json()
        token_url = well_known_data.get("token_endpoint")
        
        data = {
            'client_id': client_id,
            'client_secret': client_secret,
            'redirect_uri': redirect_uri,
            'code': auth_code
        }
        
        if flow == "OIDC":
            data['grant_type'] = 'authorization_code'
        elif flow == "OAuth":
            data['grant_type'] = 'authorization_code'
        
        token_response = requests.post(token_url, data=data, verify=False)
        token_data = token_response.json()
        access_token = token_data.get("access_token")
        id_token = token_data.get("id_token", "N/A")
        
        if flow == "OIDC":
            introspect_url = well_known_data.get("introspection_endpoint")
            introspect_response = requests.post(introspect_url, data={
                'token': access_token,
                'client_id': client_id,
                'client_secret': client_secret
            })
            introspect_data = introspect_response.json()
            userinfo_url = well_known_data.get("userinfo_endpoint")
            userinfo_response = requests.get(userinfo_url, headers={
                'Authorization': f"Bearer {access_token}"
            })
            userinfo_data = userinfo_response.json()
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, f"Access Token:\n{access_token}\n\nID Token:\n{id_token}\n\nIntrospect Response:\n{introspect_data}\n\nUserinfo Response:\n{userinfo_data}")
        elif flow == "OAuth":
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, f"Access Token:\n{access_token}\n\nID Token:\n{id_token}")
    except Exception as e:
        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, f"Error retrieving tokens: {e}")

def show_help():
    help_window = tk.Toplevel()
    help_window.title("Help")
    help_window.geometry("400x300")

    style = ttk.Style(help_window)
    colors = NORD_STYLES["standard"]
    style.configure("TFrame", background=colors["background"])
    style.configure("TLabel", background=colors["background"], foreground=colors["foreground"])
    style.configure("TButton", background=colors["button"], foreground=colors["foreground"])
    style.map("TButton", background=[("active", colors["highlight"])])

    frame = ttk.Frame(help_window, padding="10")
    frame.pack(fill=tk.BOTH, expand=True)

    help_text = (
        "Welcome to the Network Tools Application!\n\n"
        "Features:\n"
        "- NSLookup: Perform DNS lookups for a list of domains.\n"
        "- HTTPRequest: Perform HTTP requests to a list of URLs.\n"
        "- JWKSCheck: Verify certificates from a JWKS endpoint.\n"
        "- Play Audio: Play an audio file.\n"
        "- Ping Tool: Diagnose network issues by pinging hosts.\n"
        "- JWT Decoder: Decode and display JWTs.\n"
        "- SAML Decoder: Decode and display SAML tokens.\n"
        "- OIDC/OAuth Debugger: Test OIDC and OAuth using PKCE and view tokens.\n"
        "Double-click any row to delete it.\n"
    )

    ttk.Label(frame, text=help_text).pack(padx=5, pady=5)
    ttk.Button(frame, text="Close", command=help_window.destroy).pack(padx=5, pady=5)

class CustomTable:
    def __init__(self, parent, columns, row, col, columnspan=1):
        self.frame = ttk.Frame(parent)
        self.frame.grid(row=row, column=col, columnspan=columnspan, padx=5, pady=5, sticky="nsew")

        self.table = ttk.Treeview(self.frame, columns=columns, show="headings")
        for col in columns:
            self.table.heading(col, text=col)
            self.table.column(col, anchor=tk.W, width=150)
        self.table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.scrollbar_y = ttk.Scrollbar(self.frame, orient=tk.VERTICAL, command=self.table.yview)
        self.table.configure(yscroll=self.scrollbar_y.set)
        self.scrollbar_y.pack(side=tk.RIGHT, fill=tk.Y)

        self.table.bind("<Double-1>", self.delete_row)
        self.frame.rowconfigure(0, weight=1)
        self.frame.columnconfigure(0, weight=1)

    def delete_row(self, event):
        selected_item = self.table.selection()[0]
        self.table.delete(selected_item)

    def clear_table(self):
        for item in self.table.get_children():
            self.table.delete(item)

    def insert_row(self, values):
        self.table.insert("", "end", values=values)

class NSLookup:
    def __init__(self, master, style):
        self.master = master
        self.style = style
        self.is_collapsed = False
        self.setup_ui()
        self.domains = self.load_domains()
        self.update_nslookup_table()

    def setup_ui(self):
        self.frame = ttk.LabelFrame(self.master, text="NSLookup", padding="10")
        self.frame.grid(row=1, column=0, sticky="nsew")

        self.table_title_frame = ttk.Frame(self.frame)
        self.table_title_frame.grid(row=0, column=0, columnspan=4, sticky="ew")
        ttk.Label(self.table_title_frame, text="NSLookup").pack(side=tk.LEFT)

        self.collapse_btn = ttk.Button(self.table_title_frame, text="Collapse", command=self.toggle_collapse, style="Invert.TButton")
        self.collapse_btn.pack(side=tk.RIGHT, padx=5)

        self.domain_entry = ttk.Entry(self.frame, width=50)
        self.domain_entry.grid(row=1, column=0, padx=5, pady=5)
        
        self.add_domain_btn = ttk.Button(self.frame, text="Add Domain", command=self.add_domain)
        self.add_domain_btn.grid(row=1, column=1, padx=5, pady=5)

        self.refresh_btn = ttk.Button(self.frame, text="Refresh", command=self.update_nslookup_table)
        self.refresh_btn.grid(row=1, column=2, padx=5, pady=5)

        self.reset_btn = ttk.Button(self.frame, text="Reset Domains", command=self.reset_domains)
        self.reset_btn.grid(row=1, column=3, padx=5, pady=5)
        
        self.table = CustomTable(self.frame, ("Domain", "Name", "IP Address", "Region", "Timestamp"), 2, 0, 4)
        
        self.frame.rowconfigure(2, weight=1)
        self.frame.columnconfigure(0, weight=1)

    def toggle_collapse(self):
        if self.is_collapsed:
            self.table.frame.grid()
            self.domain_entry.grid()
            self.add_domain_btn.grid()
            self.refresh_btn.grid()
            self.reset_btn.grid()
            self.collapse_btn.config(text="Collapse")
        else:
            self.table.frame.grid_remove()
            self.domain_entry.grid_remove()
            self.add_domain_btn.grid_remove()
            self.refresh_btn.grid_remove()
            self.reset_btn.grid_remove()
            self.collapse_btn.config(text="Expand")
        self.is_collapsed = not self.is_collapsed

    def expand(self):
        if self.is_collapsed:
            self.toggle_collapse()
    
    def load_domains(self):
        try:
            with open("nslookup.json", "r") as file:
                return json.load(file)
        except FileNotFoundError:
            return ["google.com", "yahoo.com", "mail.com", "dogpile.com"]
    
    def save_domains(self):
        with open("nslookup.json", "w") as file:
            json.dump(self.domains, file)
    
    def add_domain(self):
        domain = self.domain_entry.get().strip()
        if domain:
            self.domains.append(domain)
            self.save_domains()
            self.update_nslookup_table()
    
    def reset_domains(self):
        self.domains = ["google.com", "yahoo.com", "mail.com", "dogpile.com"]
        self.save_domains()
        self.update_nslookup_table()
    
    def update_nslookup_table(self):
        self.table.clear_table()
        resolver = dns.resolver.Resolver()
        for domain in self.domains:
            try:
                answer = resolver.resolve(domain, 'A')
                for rdata in answer:
                    region = REGION_MAPPINGS.get(domain.split('.')[0], "unknown")
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    self.table.insert_row((domain, rdata, rdata.address, region, timestamp))
            except Exception as e:
                print(f"Error resolving {domain}: {e}")
        self.master.after(600000, self.update_nslookup_table)  # Auto-refresh every 10 minutes

class HTTPRequest:
    def __init__(self, master, style):
        self.master = master
        self.style = style
        self.is_collapsed = False
        self.setup_ui()

        self.urls = self.load_urls()
        self.update_http_table()

    def setup_ui(self):
        self.frame = ttk.LabelFrame(self.master, text="HTTPRequest", padding="10")
        self.frame.grid(row=2, column=0, sticky="nsew")

        self.table_title_frame = ttk.Frame(self.frame)
        self.table_title_frame.grid(row=0, column=0, columnspan=4, sticky="ew")
        ttk.Label(self.table_title_frame, text="HTTPRequest").pack(side=tk.LEFT)

        self.collapse_btn = ttk.Button(self.table_title_frame, text="Collapse", command=self.toggle_collapse, style="Invert.TButton")
        self.collapse_btn.pack(side=tk.RIGHT, padx=5)

        self.url_entry = ttk.Entry(self.frame, width=50)
        self.url_entry.grid(row=1, column=0, padx=5, pady=5)
        
        self.add_url_btn = ttk.Button(self.frame, text="Add URL", command=self.add_url)
        self.add_url_btn.grid(row=1, column=1, padx=5, pady=5)

        self.refresh_btn = ttk.Button(self.frame, text="Refresh", command=self.update_http_table)
        self.refresh_btn.grid(row=1, column=2, padx=5, pady=5)

        self.reset_btn = ttk.Button(self.frame, text="Reset URLs", command=self.reset_urls)
        self.reset_btn.grid(row=1, column=3, padx=5, pady=5)
        
        self.table = CustomTable(self.frame, ("URL", "Status Code", "Status Text", "Timestamp"), 2, 0, 4)
        
        self.frame.rowconfigure(2, weight=1)
        self.frame.columnconfigure(0, weight=1)

    def toggle_collapse(self):
        if self.is_collapsed:
            self.table.frame.grid()
            self.url_entry.grid()
            self.add_url_btn.grid()
            self.refresh_btn.grid()
            self.reset_btn.grid()
            self.collapse_btn.config(text="Collapse")
        else:
            self.table.frame.grid_remove()
            self.url_entry.grid_remove()
            self.add_url_btn.grid_remove()
            self.refresh_btn.grid_remove()
            self.reset_btn.grid_remove()
            self.collapse_btn.config(text="Expand")
        self.is_collapsed = not self.is_collapsed

    def expand(self):
        if self.is_collapsed:
            self.toggle_collapse()

    def load_urls(self):
        try:
            with open("urls.json", "r") as file:
                return json.load(file)
        except FileNotFoundError:
            return ["https://status.cloud.google.com", "https://portal.office.com"]

    def save_urls(self):
        with open("urls.json", "w") as file:
            json.dump(self.urls, file)

    def add_url(self):
        url = self.url_entry.get().strip()
        if url:
            self.urls.append(url)
            self.save_urls()
            self.update_http_table()

    def reset_urls(self):
        self.urls = ["https://status.cloud.google.com", "https://portal.office.com"]
        self.save_urls()
        self.update_http_table()

    def update_http_table(self):
        self.table.clear_table()
        for url in self.urls:
            try:
                response = requests.get(url,verify=False)
                status_text = response.text
                if "we’re all good" in status_text:
                    status_text = "We’re all good"
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                self.table.insert_row((url, response.status_code, status_text, timestamp))
            except Exception as e:
                print(f"Error fetching {url}: {e}")
        self.master.after(600000, self.update_http_table)  # Auto-refresh every 10 minutes

class JWKSCheck:
    def __init__(self, master, style):
        self.master = master
        self.style = style
        self.is_collapsed = False
        self.setup_ui()

        self.default_url = "https://auth.pingone.com/0a7af83d-4ed9-4510-93cd-506fe835f69a/as/jwks"
        self.url = self.default_url
        self.update_jwks_table()

    def setup_ui(self):
        self.frame = ttk.LabelFrame(self.master, text="JWKSCheck", padding="10")
        self.frame.grid(row=3, column=0, sticky="nsew")

        self.table_title_frame = ttk.Frame(self.frame)
        self.table_title_frame.grid(row=0, column=0, columnspan=4, sticky="ew")
        ttk.Label(self.table_title_frame, text="JWKSCheck").pack(side=tk.LEFT)

        self.collapse_btn = ttk.Button(self.table_title_frame, text="Collapse", command=self.toggle_collapse, style="Invert.TButton")
        self.collapse_btn.pack(side=tk.RIGHT, padx=5)

        self.url_entry = ttk.Entry(self.frame, width=50)
        #self.url_entry.insert(0, self.default_url)
        self.url_entry.insert(0, "https://auth.pingone.com/0a7af83d-4ed9-4510-93cd-506fe835f69a/as/jwks")
        self.url_entry.grid(row=1, column=0, padx=5, pady=5)
        
        self.add_url_btn = ttk.Button(self.frame, text="Set URL", command=self.set_url)
        self.add_url_btn.grid(row=1, column=1, padx=5, pady=5)

        self.refresh_btn = ttk.Button(self.frame, text="Refresh", command=self.update_jwks_table)
        self.refresh_btn.grid(row=1, column=2, padx=5, pady=5)
        
        self.cert_table = CustomTable(self.frame, ("Key ID", "Name", "Not Valid Before", "Not Valid After"), 2, 0, 4)
        self.ec_table = CustomTable(self.frame, ("Key Type", "Key ID", "Use", "X", "Y", "Curve"), 3, 0, 4)

        self.frame.rowconfigure(2, weight=1)
        self.frame.columnconfigure(0, weight=1)

    def toggle_collapse(self):
        if self.is_collapsed:
            self.cert_table.frame.grid()
            self.ec_table.frame.grid()
            self.url_entry.grid()
            self.add_url_btn.grid()
            self.refresh_btn.grid()
            self.collapse_btn.config(text="Collapse")
        else:
            self.cert_table.frame.grid_remove()
            self.ec_table.frame.grid_remove()
            self.url_entry.grid_remove()
            self.add_url_btn.grid_remove()
            self.refresh_btn.grid_remove()
            self.collapse_btn.config(text="Expand")
        self.is_collapsed = not self.is_collapsed

    def expand(self):
        if self.is_collapsed:
            self.toggle_collapse()
    
    def set_url(self):
        self.url = self.url_entry.get().strip()
        if not self.url:
            self.url = self.default_url
        self.update_jwks_table()
    
    def update_jwks_table(self):
        self.cert_table.clear_table()
        self.ec_table.clear_table()
        try:
            response = requests.get(self.url,verify=False)
            response.raise_for_status()
            jwks = response.json()
            for key in jwks.get('keys', []):
                if 'x5c' in key:
                    for cert in key['x5c']:
                        cert_bytes = base64.b64decode(cert)
                        x509_cert = x509.load_der_x509_certificate(cert_bytes, default_backend())
                        key_id = key['kid']
                        name = x509_cert.subject
                        not_valid_before = x509_cert.not_valid_before
                        not_valid_after = x509_cert.not_valid_after
                        self.cert_table.insert_row((key_id, name, not_valid_before, not_valid_after))
                if key['kty'] == 'EC':
                    key_type = key['kty']
                    key_id = key['kid']
                    use = key['use']
                    x = key.get('x', '')
                    y = key.get('y', '')
                    curve = key.get('crv', '')
                    self.ec_table.insert_row((key_type, key_id, use, x, y, curve))
        except Exception as e:
            print(f"Error fetching JWKS: {e}")
        self.master.after(600000, self.update_jwks_table)  # Auto-refresh every 10 minutes

def create_errors_file():
    file_name = 'errors.json'
    if not os.path.exists(file_name):
        with open(file_name, 'w') as file:
            json.dump([], file)
        print(f"{file_name} created.")
    else:
        print(f"{file_name} already exists.")

def open_ping_window(theme):
    ping_window = tk.Toplevel()
    ping_window.title("Ping Tool")
    ping_window.geometry("400x300")

    style = ttk.Style(ping_window)
    colors = NORD_STYLES[theme.get()]
    style.configure("TFrame", background=colors["background"])
    style.configure("TLabel", background=colors["background"], foreground=colors["foreground"])
    style.configure("TButton", background=colors["button"], foreground=colors["foreground"])
    style.map("TButton", background=[("active", colors["highlight"])])
    style.configure("TEntry", background=colors["background"], foreground=colors["foreground"], fieldbackground=colors["background"])

    frame = ttk.Frame(ping_window, padding="10")
    frame.pack(fill=tk.BOTH, expand=True)

    ttk.Label(frame, text="Enter Hostname/IP:").pack(padx=5, pady=5)
    ping_entry = ttk.Entry(frame, width=30)
    ping_entry.pack(padx=5, pady=5)

    result_text = tk.Text(frame, wrap=tk.WORD, height=10, width=40, bg=colors["background"], fg=colors["foreground"])
    result_text.pack(padx=5, pady=5)

    def ping_host():
        host = ping_entry.get().strip()
        if host:
            result_text.delete(1.0, tk.END)
            try:
                response = ping(host, count=4, verbose=True)
                result_text.insert(tk.END, str(response))
            except Exception as e:
                result_text.insert(tk.END, f"Error pinging {host}: {e}")

    ttk.Button(frame, text="Ping", command=ping_host).pack(padx=5, pady=5)
    ttk.Button(frame, text="Close", command=ping_window.destroy).pack(padx=5, pady=5)

def expand_all_tables(nslookup, http_request, jwks_check):
    nslookup.expand()
    http_request.expand()
    jwks_check.expand()

def main():
    create_errors_file()

    root = tk.Tk()
    root.title("Network Tools")
    root.geometry("1200x900")

    top_frame = ttk.Frame(root, padding="5")
    top_frame.grid(row=0, column=0, columnspan=3, sticky="ew")
    ttk.Button(top_frame, text="Play Audio", command=play_audio).pack(side=tk.LEFT, padx=5, pady=5)
    ttk.Button(top_frame, text="Expand All Tables", command=lambda: expand_all_tables(nslookup, http_request, jwks_check)).pack(side=tk.LEFT, padx=5, pady=5)
    ttk.Button(top_frame, text="Help", command=show_help).pack(side=tk.RIGHT, padx=5, pady=5)

    canvas = tk.Canvas(root)
    scrollbar = ttk.Scrollbar(root, orient="vertical", command=canvas.yview)
    scrollable_frame = ttk.Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.grid(row=1, column=0, columnspan=2, sticky="nsew")
    scrollbar.grid(row=1, column=2, sticky="ns")

    for i in range(4):
        root.rowconfigure(i + 1, weight=1)
    root.columnconfigure(0, weight=1)
    root.columnconfigure(1, weight=0)

    theme_var = tk.StringVar(value="standard")
    
    # Sidebar for theme selection
    sidebar = ttk.Frame(scrollable_frame, padding="5")
    sidebar.grid(row=0, column=1, rowspan=4, sticky="ns")

    logo = Image.open("3452030819_782498355d.jpg")
    logo = logo.resize((100, 50), Image.Resampling.LANCZOS)
    logo_img = ImageTk.PhotoImage(logo)
    logo_label = ttk.Label(sidebar, image=logo_img)
    logo_label.image = logo_img
    logo_label.grid(row=0, column=0, padx=5, pady=5)

    ttk.Label(sidebar, text="Choose Theme:").grid(row=1, column=0, padx=5, pady=5)
    ttk.Radiobutton(sidebar, text="Nord", variable=theme_var, value="standard", command=lambda: apply_theme(theme_var.get())).grid(row=2, column=0, padx=5, pady=5)
    ttk.Radiobutton(sidebar, text="Frost", variable=theme_var, value="frost", command=lambda: apply_theme(theme_var.get())).grid(row=3, column=0, padx=5, pady=5)
    ttk.Radiobutton(sidebar, text="Aurora", variable=theme_var, value="aurora", command=lambda: apply_theme(theme_var.get())).grid(row=4, column=0, padx=5, pady=5)
    ttk.Button(sidebar, text="Open Ping Tool", command=lambda: open_ping_window(theme_var)).grid(row=5, column=0, padx=5, pady=5)
    ttk.Button(sidebar, text="JWT Decoder", command=lambda: open_jwt_window(theme_var)).grid(row=6, column=0, padx=5, pady=5)
    ttk.Button(sidebar, text="SAML Decoder", command=lambda: open_saml_window(theme_var)).grid(row=7, column=0, padx=5, pady=5)
    ttk.Button(sidebar, text="OIDC/OAuth Debugger", command=lambda: open_oidc_window(theme_var)).grid(row=8, column=0, padx=5, pady=5)

    nslookup = NSLookup(scrollable_frame, theme_var)
    http_request = HTTPRequest(scrollable_frame, theme_var)
    jwks_check = JWKSCheck(scrollable_frame, theme_var)

    apply_theme(theme_var.get())
    nslookup.expand()
    http_request.expand()
    jwks_check.expand()
    root.mainloop()

if __name__ == "__main__":
    main()

