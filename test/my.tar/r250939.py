import os
import json
import dns.resolver
import requests
import base64
from datetime import datetime
from cryptography import x509
from cryptography.hazmat.backends import default_backend
import tkinter as tk
from tkinter import ttk
from pythonping import ping
import ssl
import pygame
from PIL import Image, ImageTk
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import warnings

#Silence Self Signed Certificate Errors
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
warnings.filterwarnings("ignore")

# Styling configurations
NORD_STYLES = {
    "standard": {
        "background": "#2E3440",
        "foreground": "#D8DEE9",
        "highlight": "#88C0D0",
        "error": "#BF616A",
        "header": "#4C566A",
        "row_odd": "#3B4252",
        "row_even": "#434C5E",
        "button": "#5E81AC",
        "invert_button": "#BF616A"
    },
    "frost": {
        "background": "#8FBCBB",
        "foreground": "#2E3440",
        "highlight": "#88C0D0",
        "error": "#BF616A",
        "header": "#4C566A",
        "row_odd": "#A3BE8C",
        "row_even": "#EBCB8B",
        "button": "#5E81AC",
        "invert_button": "#D08770"
    },
    "aurora": {
        "background": "#A3BE8C",
        "foreground": "#2E3440",
        "highlight": "#88C0D0",
        "error": "#BF616A",
        "header": "#4C566A",
        "row_odd": "#B48EAD",
        "row_even": "#D08770",
        "button": "#5E81AC",
        "invert_button": "#88C0D0"
    }
}

REGION_MAPPINGS = {
    "prod0": "eu-west-1",
    "prod1": "eu-west-2",
    "qa0": "eu-west",
    "qa1": "eu-east",
    "qa3": "ca-central",
    "qa4": "eu-central1"
}

def apply_theme(theme):
    style = ttk.Style()
    colors = NORD_STYLES[theme]
    style.configure("TFrame", background=colors["background"])
    style.configure("TLabelFrame", background=colors["background"], foreground=colors["foreground"])
    style.configure("Treeview", background=colors["background"], foreground=colors["foreground"], fieldbackground=colors["background"])
    style.configure("Treeview.Heading", background=colors["header"], foreground=colors["foreground"])
    style.configure("TButton", background=colors["button"], foreground=colors["foreground"])
    style.map("TButton", background=[("active", colors["highlight"])])
    style.configure("TEntry", background=colors["background"], foreground=colors["foreground"], fieldbackground=colors["background"])
    style.configure("TText", background=colors["background"], foreground=colors["foreground"])
    style.configure("Invert.TButton", background=colors["invert_button"], foreground=colors["foreground"])
    style.map("Invert.TButton", background=[("active", colors["highlight"])])

def play_audio():
    pygame.mixer.init()
    pygame.mixer.music.load("https://storage.googleapis.com/soundboards/Cartoons/THE%20SIMPSONS/MR%20BURNS/MP3/EXCELLENT%20-%20AUDIO%20FROM%20JAYUZUMI.COM.mp3")
    pygame.mixer.music.play()

class CustomWindow:
    def __init__(self, title, width, height, theme):
        self.window = tk.Toplevel()
        self.window.title(title)
        self.window.geometry(f"{width}x{height}")
        self.theme = theme
        self.apply_theme()

        self.frame = ttk.Frame(self.window, padding="10")
        self.frame.pack(fill=tk.BOTH, expand=True)

    def apply_theme(self):
        style = ttk.Style(self.window)
        colors = NORD_STYLES[self.theme.get()]
        style.configure("TFrame", background=colors["background"])
        style.configure("TLabel", background=colors["background"], foreground=colors["foreground"])
        style.configure("TButton", background=colors["button"], foreground=colors["foreground"])
        style.map("TButton", background=[("active", colors["highlight"])])
        style.configure("TEntry", background=colors["background"], foreground=colors["foreground"], fieldbackground=colors["background"])
        style.configure("TText", background=colors["background"], foreground=colors["foreground"])

    def add_scrollbar(self, widget):
        scrollbar = ttk.Scrollbar(self.frame, orient=tk.VERTICAL, command=widget.yview)
        widget.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

def create_labeled_entry(frame, text, row, col, width=50):
    ttk.Label(frame, text=text).grid(row=row, column=col, padx=5, pady=5)
    entry = ttk.Entry(frame, width=width)
    entry.grid(row=row + 1, column=col, padx=5, pady=5, sticky="ew")
    return entry

def create_scrollable_text(frame, height, width, theme, row, col, colspan=1):
    text_widget = tk.Text(frame, wrap=tk.WORD, height=height, width=width, bg=NORD_STYLES[theme.get()]["background"], fg=NORD_STYLES[theme.get()]["foreground"])
    text_widget.grid(row=row, column=col, columnspan=colspan, padx=5, pady=5, sticky="nsew")
    scrollbar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=text_widget.yview)
    text_widget.configure(yscrollcommand=scrollbar.set)
    scrollbar.grid(row=row, column=col + colspan, sticky="ns")
    return text_widget

def fetch_well_known(endpoint, result_text):
    try:
        response = requests.get(endpoint, verify=False)
        response.raise_for_status()
        well_known_data = response.json()
        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, json.dumps(well_known_data, indent=4))
    except Exception as e:
        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, f"Error fetching well-known endpoint: {e}")

def get_tokens(well_known_url, client_id, client_secret, redirect_uri, auth_code, result_text, flow):
    try:
        well_known_response = requests.get(well_known_url, verify=False)
        well_known_response.raise_for_status()
        well_known_data = well_known_response.json()
        token_url = well_known_data.get("token_endpoint")

        data = {
            'client_id': client_id,
            'client_secret': client_secret,
            'redirect_uri': redirect_uri,
            'code': auth_code
        }

        data['grant_type'] = 'authorization_code'

        token_response = requests.post(token_url, verify=False, data=data)
        token_data = token_response.json()
        access_token = token_data.get("access_token")
        id_token = token_data.get("id_token", "N/A")

        if flow == "OIDC":
            introspect_url = well_known_data.get("introspection_endpoint")
            introspect_response = requests.post(introspect_url, verify=False, data={
                'token': access_token,
                'client_id': client_id,
                'client_secret': client_secret
            })
            introspect_data = introspect_response.json()
            userinfo_url = well_known_data.get("userinfo_endpoint")
            userinfo_response = requests.get(userinfo_url, verify=False, headers={
                'Authorization': f"Bearer {access_token}"
            })
            userinfo_data = userinfo_response.json()
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, f"Access Token:\n{access_token}\n\nID Token:\n{id_token}\n\nIntrospect Response:\n{introspect_data}\n\nUserinfo Response:\n{userinfo_data}")
        elif flow == "OAuth":
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, f"Access Token:\n{access_token}\n\nID Token:\n{id_token}")
    except Exception as e:
        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, f"Error retrieving tokens: {e}")

def open_jwt_window(theme):
    jwt_window = CustomWindow("JWT Decoder", 500, 400, theme)
    frame = jwt_window.frame

    create_labeled_entry(frame, "Enter JWT:", 0, 0)
    jwt_entry = ttk.Entry(frame, width=50)
    jwt_entry.grid(row=1, column=0, padx=5, pady=5)

    result_text = create_scrollable_text(frame, 10, 40, theme, 2, 0, 2)

    def decode_jwt():
        jwt_token = jwt_entry.get().strip()
        try:
            header, payload, signature = jwt_token.split('.')
            decoded_header = base64.urlsafe_b64decode(header + '==').decode('utf-8')
            decoded_payload = base64.urlsafe_b64decode(payload + '==').decode('utf-8')
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, f"Header:\n{decoded_header}\n\nPayload:\n{decoded_payload}\n\nSignature:\n{signature}")
        except Exception as e:
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, f"Error decoding JWT: {e}")

    ttk.Button(frame, text="Decode", command=decode_jwt).grid(row=3, column=0, padx=5, pady=5)
    ttk.Button(frame, text="Close", command=jwt_window.window.destroy).grid(row=4, column=0, padx=5, pady=5)

def open_saml_window(theme):
    saml_window = CustomWindow("SAML Decoder", 500, 400, theme)
    frame = saml_window.frame

    create_labeled_entry(frame, "Enter SAML:", 0, 0)
    saml_entry = ttk.Entry(frame, width=50)
    saml_entry.grid(row=1, column=0, padx=5, pady=5)

    result_text = create_scrollable_text(frame, 10, 40, theme, 2, 0, 2)

    def decode_saml():
        saml_token = saml_entry.get().strip()
        try:
            decoded_saml = base64.b64decode(saml_token).decode('utf-8')
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, decoded_saml)
        except Exception as e:
            result_text.delete(1.0, tk.END)
            result_text.insert(tk.END, f"Error decoding SAML: {e}")

    ttk.Button(frame, text="Decode", command=decode_saml).grid(row=3, column=0, padx=5, pady=5)
    ttk.Button(frame, text="Close", command=saml_window.window.destroy).grid(row=4, column=0, padx=5, pady=5)

def open_oidc_window(theme, well_known_data=None):
    oidc_window = CustomWindow("OIDC Debugger", 1000, 900, theme)
    frame = oidc_window.frame

    well_known_entry = create_labeled_entry(frame, "OIDC Well-Known Endpoint:", 0, 0)
    if well_known_data:
        well_known_entry.insert(0, well_known_data)

    result_text = create_scrollable_text(frame, 10, 60, theme, 2, 0, 2)

    ttk.Button(frame, text="Fetch Well-Known", command=lambda: fetch_well_known(well_known_entry.get(), result_text)).grid(row=1, column=1, padx=5, pady=5)

    client_id_entry = create_labeled_entry(frame, "Client ID:", 3, 0)
    client_secret_entry = create_labeled_entry(frame, "Client Secret:", 5, 0)
    redirect_uri_entry = create_labeled_entry(frame, "Redirect URI:", 7, 0)
    auth_code_entry = create_labeled_entry(frame, "Authorization Code:", 9, 0)
    scopes_entry = create_labeled_entry(frame, "Scopes (space-separated):", 11, 0)

    request_table_frame = ttk.Frame(frame)
    request_table_frame.grid(row=0, column=3, rowspan=12, padx=10, pady=10, sticky="nsew")

    request_table = CustomTable(request_table_frame, ("Parameter", "Value"), 0, 0)

    introspection_frame = ttk.Frame(frame)
    introspection_frame.grid(row=12, column=3, rowspan=5, padx=10, pady=10, sticky="nsew")

    introspection_request_table = CustomTable(introspection_frame, ("Parameter", "Value"), 0, 0)
    introspection_response_table = CustomTable(introspection_frame, ("Field", "Value"), 1, 0)

    def update_request_table():
        request_table.clear_table()
        request_table.insert_row(("Client ID", client_id_entry.get()))
        request_table.insert_row(("Client Secret", client_secret_entry.get()))
        request_table.insert_row(("Redirect URI", redirect_uri_entry.get()))
        request_table.insert_row(("Authorization Code", auth_code_entry.get()))
        request_table.insert_row(("Scopes", scopes_entry.get()))

    def get_and_display_tokens():
        update_request_table()
        well_known_url = well_known_entry.get()
        client_id = client_id_entry.get()
        client_secret = client_secret_entry.get()
        redirect_uri = redirect_uri_entry.get()
        auth_code = auth_code_entry.get()
        scopes = scopes_entry.get()
        result_text.delete(1.0, tk.END)
        introspection_request_table.clear_table()
        introspection_response_table.clear_table()
        try:
            well_known_response = requests.get(well_known_url, verify=False)
            well_known_response.raise_for_status()
            well_known_data = well_known_response.json()
            token_url = well_known_data.get("token_endpoint")
            introspect_url = well_known_data.get("introspection_endpoint")

            data = {
                'client_id': client_id,
                'client_secret': client_secret,
                'redirect_uri': redirect_uri,
                'code': auth_code,
                'grant_type': 'authorization_code',
                'scope': scopes
            }

            request_text = f"POST {token_url}\n\n"
            for key, value in data.items():
                request_text += f"{key}: {value}\n"
            result_text.insert(tk.END, request_text + "\n\n")

            token_response = requests.post(token_url, verify=False, data=data)
            token_response.raise_for_status()
            token_data = token_response.json()

            access_token = token_data.get("access_token")
            id_token = token_data.get("id_token", "N/A")

            result_text.insert(tk.END, f"Access Token:\n{access_token}\n\nID Token:\n{id_token}\n\n")

            introspect_data = {
                'token': access_token,
                'client_id': client_id,
                'client_secret': client_secret
            }

            introspection_request_table.insert_row(("token", access_token))
            introspection_request_table.insert_row(("client_id", client_id))
            introspection_request_table.insert_row(("client_secret", client_secret))

            introspect_response = requests.post(introspect_url, verify=False, data=introspect_data)
            introspect_response.raise_for_status()
            introspect_response_data = introspect_response.json()

            for key, value in introspect_response_data.items():
                introspection_response_table.insert_row((key, value))

        except Exception as e:
            result_text.insert(tk.END, f"Error retrieving tokens or introspection: {e}")

    ttk.Button(frame, text="Get Tokens", command=get_and_display_tokens).grid(row=13, column=1, padx=5, pady=5)
    ttk.Button(frame, text="Close", command=oidc_window.window.destroy).grid(row=14, column=1, padx=5, pady=5, sticky="e")

def open_oauth_window(theme, well_known_data=None):
    oauth_window = CustomWindow("OAuth Debugger", 1000, 900, theme)
    frame = oauth_window.frame

    well_known_entry = create_labeled_entry(frame, "OAuth Well-Known Endpoint:", 0, 0)
    if well_known_data:
        well_known_entry.insert(0, well_known_data)

    result_text = create_scrollable_text(frame, 10, 60, theme, 2, 0, 2)

    ttk.Button(frame, text="Fetch Well-Known", command=lambda: fetch_well_known(well_known_entry.get(), result_text)).grid(row=1, column=1, padx=5, pady=5)

    client_id_entry = create_labeled_entry(frame, "Client ID:", 3, 0)
    client_secret_entry = create_labeled_entry(frame, "Client Secret:", 5, 0)
    scopes_entry = create_labeled_entry(frame, "Scopes (space-separated):", 7, 0)

    request_table_frame = ttk.Frame(frame)
    request_table_frame.grid(row=0, column=3, rowspan=9, padx=10, pady=10, sticky="nsew")

    request_table = CustomTable(request_table_frame, ("Parameter", "Value"), 0, 0)

    introspection_frame = ttk.Frame(frame)
    introspection_frame.grid(row=9, column=3, rowspan=5, padx=10, pady=10, sticky="nsew")

    introspection_request_table = CustomTable(introspection_frame, ("Parameter", "Value"), 0, 0)
    introspection_response_table = CustomTable(introspection_frame, ("Field", "Value"), 1, 0)

    def update_request_table():
        request_table.clear_table()
        request_table.insert_row(("Client ID", client_id_entry.get()))
        request_table.insert_row(("Client Secret", client_secret_entry.get()))
        request_table.insert_row(("Scopes", scopes_entry.get()))

    def get_and_display_tokens():
        update_request_table()
        well_known_url = well_known_entry.get()
        client_id = client_id_entry.get()
        client_secret = client_secret_entry.get()
        scopes = scopes_entry.get()
        result_text.delete(1.0, tk.END)
        introspection_request_table.clear_table()
        introspection_response_table.clear_table()
        try:
            well_known_response = requests.get(well_known_url, verify=False)
            well_known_response.raise_for_status()
            well_known_data = well_known_response.json()
            token_url = well_known_data.get("token_endpoint")
            introspect_url = well_known_data.get("introspection_endpoint")

            data = {
                'client_id': client_id,
                'client_secret': client_secret,
                'grant_type': 'client_credentials',
                'scope': scopes
            }

            request_text = f"POST {token_url}\n\n"
            for key, value in data.items():
                request_text += f"{key}: {value}\n"
            result_text.insert(tk.END, request_text + "\n\n")

            token_response = requests.post(token_url, verify=False, data=data)
            token_response.raise_for_status()
            token_data = token_response.json()

            access_token = token_data.get("access_token")
            id_token = token_data.get("id_token", "N/A")

            result_text.insert(tk.END, f"Access Token:\n{access_token}\n\nID Token:\n{id_token}\n\n")

            introspect_data = {
                'token': access_token,
                'client_id': client_id,
                'client_secret': client_secret
            }

            introspection_request_table.insert_row(("token", access_token))
            introspection_request_table.insert_row(("client_id", client_id))
            introspection_request_table.insert_row(("client_secret", client_secret))

            introspect_response = requests.post(introspect_url, verify=False, data=introspect_data)
            introspect_response.raise_for_status()
            introspect_response_data = introspect_response.json()

            for key, value in introspect_response_data.items():
                introspection_response_table.insert_row((key, value))

        except Exception as e:
            result_text.insert(tk.END, f"Error retrieving tokens or introspection: {e}")

    ttk.Button(frame, text="Get Tokens", command=get_and_display_tokens).grid(row=9, column=1, padx=5, pady=5)
    ttk.Button(frame, text="Close", command=oauth_window.window.destroy).grid(row=10, column=1, padx=5, pady=5, sticky="e")

class CustomTable:
    def __init__(self, parent, columns, row, col, columnspan=1):
        self.frame = ttk.Frame(parent)
        self.frame.grid(row=row, column=col, columnspan=columnspan, padx=5, pady=5, sticky="nsew")

        self.table = ttk.Treeview(self.frame, columns=columns, show="headings")
        for col in columns:
            self.table.heading(col, text=col)
            self.table.column(col, anchor=tk.W, width=150)
        self.table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.scrollbar_y = ttk.Scrollbar(self.frame, orient=tk.VERTICAL, command=self.table.yview)
        self.scrollbar_x = ttk.Scrollbar(self.frame, orient=tk.HORIZONTAL, command=self.table.xview)
        self.table.configure(yscroll=self.scrollbar_y.set, xscroll=self.scrollbar_x.set)
        self.scrollbar_y.pack(side=tk.RIGHT, fill=tk.Y)
        self.scrollbar_x.pack(side=tk.BOTTOM, fill=tk.X)

        self.table.bind("<Double-1>", self.delete_row)
        self.frame.rowconfigure(0, weight=1)
        self.frame.columnconfigure(0, weight=1)

    def delete_row(self, event):
        selected_item = self.table.selection()[0]
        self.table.delete(selected_item)

    def clear_table(self):
        for item in self.table.get_children():
            self.table.delete(item)

    def insert_row(self, values):
        if all(v == "" for v in values):
            return
        self.table.insert("", "end", values=values)


class NSLookup:
    def __init__(self, master, style):
        self.master = master
        self.style = style
        self.is_collapsed = False
        self.setup_ui()
        self.domains = self.load_domains()
        self.update_nslookup_table()

    def setup_ui(self):
        self.frame = ttk.LabelFrame(self.master, text="NSLookup", padding="10")
        self.frame.grid(row=1, column=0, sticky="nsew")

        self.table_title_frame = ttk.Frame(self.frame)
        self.table_title_frame.grid(row=0, column=0, columnspan=4, sticky="ew")
        ttk.Label(self.table_title_frame, text="NSLookup").pack(side=tk.LEFT)

        self.collapse_btn = ttk.Button(self.table_title_frame, text="Collapse", command=self.toggle_collapse, style="Invert.TButton")
        self.collapse_btn.pack(side=tk.RIGHT, padx=5)

        self.domain_entry = ttk.Entry(self.frame, width=50)
        self.domain_entry.grid(row=1, column=0, padx=5, pady=5)
        
        self.add_domain_btn = ttk.Button(self.frame, text="Add Domain", command=self.add_domain)
        self.add_domain_btn.grid(row=1, column=1, padx=5, pady=5)

        self.refresh_btn = ttk.Button(self.frame, text="Refresh", command=self.update_nslookup_table)
        self.refresh_btn.grid(row=1, column=2, padx=5, pady=5)

        self.reset_btn = ttk.Button(self.frame, text="Reset Domains", command=self.reset_domains)
        self.reset_btn.grid(row=1, column=3, padx=5, pady=5)
        
        self.table = CustomTable(self.frame, ("Domain", "Name", "IP Address", "Region", "Timestamp"), 2, 0, 4)
        
        self.frame.rowconfigure(2, weight=1)
        self.frame.columnconfigure(0, weight=1)

    def toggle_collapse(self):
        if self.is_collapsed:
            self.table.frame.grid()
            self.domain_entry.grid()
            self.add_domain_btn.grid()
            self.refresh_btn.grid()
            self.reset_btn.grid()
            self.collapse_btn.config(text="Collapse")
        else:
            self.table.frame.grid_remove()
            self.domain_entry.grid_remove()
            self.add_domain_btn.grid_remove()
            self.refresh_btn.grid_remove()
            self.reset_btn.grid_remove()
            self.collapse_btn.config(text="Expand")
        self.is_collapsed = not self.is_collapsed

    def expand(self):
        if self.is_collapsed:
            self.toggle_collapse()
    
    def load_domains(self):
        try:
            with open("nslookup.json", "r") as file:
                return json.load(file)
        except FileNotFoundError:
            return ["google.com", "yahoo.com", "mail.com", "dogpile.com"]
    
    def save_domains(self):
        with open("nslookup.json", "w") as file:
            json.dump(self.domains, file)
    
    def add_domain(self):
        domain = self.domain_entry.get().strip()
        if domain:
            self.domains.append(domain)
            self.save_domains()
            self.update_nslookup_table()
    
    def reset_domains(self):
        self.domains = ["google.com", "yahoo.com", "mail.com", "dogpile.com"]
        self.save_domains()
        self.update_nslookup_table()
    
    def update_nslookup_table(self):
        self.table.clear_table()
        resolver = dns.resolver.Resolver()
        for domain in self.domains:
            try:
                answer = resolver.resolve(domain, 'A')
                for rdata in answer:
                    region = REGION_MAPPINGS.get(domain.split('.')[0], "unknown")
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    self.table.insert_row((domain, rdata, rdata.address, region, timestamp))
            except Exception as e:
                print(f"Error resolving {domain}: {e}")
        self.master.after(600000, self.update_nslookup_table)  # Auto-refresh every 10 minutes

class HTTPRequest:
    def __init__(self, master, style):
        self.master = master
        self.style = style
        self.is_collapsed = False
        self.setup_ui()
        self.ignore_ssl_verification = False

        self.urls = self.load_urls()
        self.update_http_table()

    def setup_ui(self):
        self.frame = ttk.LabelFrame(self.master, text="HTTPRequest", padding="10")
        self.frame.grid(row=2, column=0, sticky="nsew")

        self.table_title_frame = ttk.Frame(self.frame)
        self.table_title_frame.grid(row=0, column=0, columnspan=4, sticky="ew")
        ttk.Label(self.table_title_frame, text="HTTPRequest").pack(side=tk.LEFT)

        self.collapse_btn = ttk.Button(self.table_title_frame, text="Collapse", command=self.toggle_collapse, style="Invert.TButton")
        self.collapse_btn.pack(side=tk.RIGHT, padx=5)

        self.url_entry = ttk.Entry(self.frame, width=50)
        self.url_entry.grid(row=1, column=0, padx=5, pady=5)
        
        self.add_url_btn = ttk.Button(self.frame, text="Add URL", command=self.add_url)
        self.add_url_btn.grid(row=1, column=1, padx=5, pady=5)

        self.refresh_btn = ttk.Button(self.frame, text="Refresh", command=self.update_http_table)
        self.refresh_btn.grid(row=1, column=2, padx=5, pady=5)

        self.reset_btn = ttk.Button(self.frame, text="Reset URLs", command=self.reset_urls)
        self.reset_btn.grid(row=1, column=3, padx=5, pady=5)

        self.ignore_ssl_btn = ttk.Button(self.frame, text="Ignore SSL Verification", command=self.toggle_ssl_verification)
        self.ignore_ssl_btn.grid(row=1, column=4, padx=5, pady=5)
        
        self.table = CustomTable(self.frame, ("URL", "Status Code", "Status Text", "Timestamp"), 2, 0, 4)
        
        self.frame.rowconfigure(2, weight=1)
        self.frame.columnconfigure(0, weight=1)

    def toggle_collapse(self):
        if self.is_collapsed:
            self.table.frame.grid()
            self.url_entry.grid()
            self.add_url_btn.grid()
            self.refresh_btn.grid()
            self.reset_btn.grid()
            self.ignore_ssl_btn.grid()
            self.collapse_btn.config(text="Collapse")
        else:
            self.table.frame.grid_remove()
            self.url_entry.grid_remove()
            self.add_url_btn.grid_remove()
            self.refresh_btn.grid_remove()
            self.reset_btn.grid_remove()
            self.ignore_ssl_btn.grid_remove()
            self.collapse_btn.config(text="Expand")
        self.is_collapsed = not self.is_collapsed

    def toggle_ssl_verification(self):
        self.ignore_ssl_verification = not self.ignore_ssl_verification
        btn_text = "Verify SSL" if self.ignore_ssl_verification else "Ignore SSL Verification"
        self.ignore_ssl_btn.config(text=btn_text)

    def expand(self):
        if self.is_collapsed:
            self.toggle_collapse()

    def load_urls(self):
        try:
            with open("urls.json", "r") as file:
                return json.load(file)
        except FileNotFoundError:
            return ["https://status.cloud.google.com", "https://portal.office.com"]

    def save_urls(self):
        with open("urls.json", "w") as file:
            json.dump(self.urls, file)

    def add_url(self):
        url = self.url_entry.get().strip()
        if url:
            self.urls.append(url)
            self.save_urls()
            self.update_http_table()

    def reset_urls(self):
        self.urls = ["https://status.cloud.google.com", "https://portal.office.com"]
        self.save_urls()
        self.update_http_table()

    def update_http_table(self):
        self.table.clear_table()
        for url in self.urls:
            try:
                response = requests.get(url, verify=not self.ignore_ssl_verification)
                status_text = response.text
                if "we’re all good" in status_text:
                    status_text = "We’re all good"
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                self.table.insert_row((url, response.status_code, status_text, timestamp))
            except Exception as e:
                print(f"Error fetching {url}: {e}")
        self.master.after(600000, self.update_http_table)  # Auto-refresh every 10 minutes

class JWKSCheck:
    def __init__(self, master, style):
        self.master = master
        self.style = style
        self.is_collapsed = False
        self.setup_ui()

        self.default_url = "https://auth.pingone.com/0a7af83d-4ed9-4510-93cd-506fe835f69a/as/jwks"
        self.url = self.default_url
        self.update_jwks_table()

    def setup_ui(self):
        self.frame = ttk.LabelFrame(self.master, text="JWKSCheck", padding="10")
        self.frame.grid(row=3, column=0, sticky="nsew")

        self.table_title_frame = ttk.Frame(self.frame)
        self.table_title_frame.grid(row=0, column=0, columnspan=4, sticky="ew")
        ttk.Label(self.table_title_frame, text="JWKSCheck").pack(side=tk.LEFT)

        self.collapse_btn = ttk.Button(self.table_title_frame, text="Collapse", command=self.toggle_collapse, style="Invert.TButton")
        self.collapse_btn.pack(side=tk.RIGHT, padx=5)

        self.url_entry = ttk.Entry(self.frame, width=50)
        #self.url_entry.insert(0, self.default_url)
        self.url_entry.insert(0, "https://auth.pingone.com/0a7af83d-4ed9-4510-93cd-506fe835f69a/as/jwks")
        self.url_entry.grid(row=1, column=0, padx=5, pady=5)
        
        self.add_url_btn = ttk.Button(self.frame, text="Set URL", command=self.set_url)
        self.add_url_btn.grid(row=1, column=1, padx=5, pady=5)

        self.refresh_btn = ttk.Button(self.frame, text="Refresh", command=self.update_jwks_table)
        self.refresh_btn.grid(row=1, column=2, padx=5, pady=5)
        
        self.cert_table = CustomTable(self.frame, ("Key ID", "Name", "Not Valid Before", "Not Valid After"), 2, 0, 4)
        self.ec_table = CustomTable(self.frame, ("Key Type", "Key ID", "Use", "X", "Y", "Curve"), 3, 0, 4)

        self.frame.rowconfigure(2, weight=1)
        self.frame.columnconfigure(0, weight=1)

    def toggle_collapse(self):
        if self.is_collapsed:
            self.cert_table.frame.grid()
            self.ec_table.frame.grid()
            self.url_entry.grid()
            self.add_url_btn.grid()
            self.refresh_btn.grid()
            self.collapse_btn.config(text="Collapse")
        else:
            self.cert_table.frame.grid_remove()
            self.ec_table.frame.grid_remove()
            self.url_entry.grid_remove()
            self.add_url_btn.grid_remove()
            self.refresh_btn.grid_remove()
            self.collapse_btn.config(text="Expand")
        self.is_collapsed = not self.is_collapsed

    def expand(self):
        if self.is_collapsed:
            self.toggle_collapse()
    
    def set_url(self):
        self.url = self.url_entry.get().strip()
        if not self.url:
            self.url = self.default_url
        self.update_jwks_table()
    
    def update_jwks_table(self):
        self.cert_table.clear_table()
        self.ec_table.clear_table()
        try:
            response = requests.get(self.url, verify=False)
            response.raise_for_status()
            jwks = response.json()
            for key in jwks.get('keys', []):
                if 'x5c' in key:
                    for cert in key['x5c']:
                        cert_bytes = base64.b64decode(cert)
                        x509_cert = x509.load_der_x509_certificate(cert_bytes, default_backend())
                        key_id = key['kid']
                        name = x509_cert.subject
                        not_valid_before = x509_cert.not_valid_before
                        not_valid_after = x509_cert.not_valid_after
                        self.cert_table.insert_row((key_id, name, not_valid_before, not_valid_after))
                if key['kty'] == 'EC':
                    key_type = key['kty']
                    key_id = key['kid']
                    use = key['use']
                    x = key.get('x', '')
                    y = key.get('y', '')
                    curve = key.get('crv', '')
                    self.ec_table.insert_row((key_type, key_id, use, x, y, curve))
        except Exception as e:
            print(f"Error fetching JWKS: {e}")
        self.master.after(600000, self.update_jwks_table)  # Auto-refresh every 10 minutes

def expand_all_tables(nslookup, http_request, jwks_check):
    nslookup.expand()
    http_request.expand()
    jwks_check.expand()

def create_errors_file():
    file_name = 'errors.json'
    if not os.path.exists(file_name):
        with open(file_name, 'w') as file:
            json.dump([], file)
        print(f"{file_name} created.")
    else:
        print(f"{file_name} already exists.")

def show_help():
    help_window = tk.Toplevel()
    help_window.title("Help")
    help_window.geometry("400x300")

    style = ttk.Style(help_window)
    colors = NORD_STYLES["standard"]
    style.configure("TFrame", background=colors["background"])
    style.configure("TLabel", background=colors["background"], foreground=colors["foreground"])
    style.configure("TButton", background=colors["button"], foreground=colors["foreground"])
    style.map("TButton", background=[("active", colors["highlight"])])

    frame = ttk.Frame(help_window, padding="10")
    frame.pack(fill=tk.BOTH, expand=True)

    help_text = (
        "Welcome to the Network Tools Application!\n\n"
        "Features:\n"
        "- NSLookup: Perform DNS lookups for a list of domains.\n"
        "- HTTPRequest: Perform HTTP requests to a list of URLs.\n"
        "- JWKSCheck: Verify certificates from a JWKS endpoint.\n"
        "- Play Audio: Play an audio file.\n"
        "- Ping Tool: Diagnose network issues by pinging hosts.\n"
        "- JWT Decoder: Decode and display JWTs.\n"
        "- SAML Decoder: Decode and display SAML tokens.\n"
        "- OIDC Debugger: Test OIDC using PKCE and view tokens.\n"
        "- OAuth Debugger: Test OAuth using Client Credentials and view tokens.\n"
        "- SSL Certificate Reader: Read and display SSL certificate details.\n"
        "Double-click any row to delete it.\n"
    )

    ttk.Label(frame, text=help_text).pack(padx=5, pady=5)
    ttk.Button(frame, text="Close", command=help_window.destroy).pack(padx=5, pady=5)

def main():
    create_errors_file()

    root = tk.Tk()
    root.title("Network Tools")
    root.geometry("1200x600")
    top_frame = ttk.Frame(root, padding="5")
    top_frame.grid(row=0, column=0, columnspan=3, sticky="ew")
    ttk.Button(top_frame, text="Play Audio", command=play_audio).pack(side=tk.LEFT, padx=5, pady=5)
    ttk.Button(top_frame, text="Expand All Tables", command=lambda: expand_all_tables(nslookup, http_request, jwks_check)).pack(side=tk.LEFT, padx=5, pady=5)
    ttk.Button(top_frame, text="Help", command=show_help).pack(side=tk.RIGHT, padx=5, pady=5)

    canvas = tk.Canvas(root)
    scrollbar = ttk.Scrollbar(root, orient="vertical", command=canvas.yview)
    scrollbar_x = ttk.Scrollbar(root, orient="horizontal", command=canvas.xview)
    scrollable_frame = ttk.Frame(canvas)


    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set, xscrollcommand=scrollbar_x.set)

    canvas.grid(row=1, column=0, columnspan=3, sticky="nsew")
    scrollbar.grid(row=1, column=3, sticky="ns")
    scrollbar_x.grid(row=2, column=0, columnspan=3, sticky="ew")

    for i in range(5):
        root.rowconfigure(i + 1, weight=1)
    root.columnconfigure(0, weight=1)
    root.columnconfigure(1, weight=0)

    theme_var = tk.StringVar(value="standard")
    
    # Sidebar for theme selection
    sidebar = ttk.Frame(scrollable_frame, padding="5")
    sidebar.grid(row=0, column=1, rowspan=5, sticky="ns")

    logo = Image.open("3452030819_782498355d.jpg")
    logo = logo.resize((100, 50), Image.Resampling.LANCZOS)
    logo_img = ImageTk.PhotoImage(logo)
    logo_label = ttk.Label(sidebar, image=logo_img)
    logo_label.image = logo_img
    logo_label.grid(row=0, column=0, padx=5, pady=5)

    ttk.Label(sidebar, text="Choose Theme:").grid(row=1, column=0, padx=5, pady=5)
    ttk.Radiobutton(sidebar, text="Nord", variable=theme_var, value="standard", command=lambda: apply_theme(theme_var.get())).grid(row=2, column=0, padx=5, pady=5)
    ttk.Radiobutton(sidebar, text="Frost", variable=theme_var, value="frost", command=lambda: apply_theme(theme_var.get())).grid(row=3, column=0, padx=5, pady=5)
    ttk.Radiobutton(sidebar, text="Aurora", variable=theme_var, value="aurora", command=lambda: apply_theme(theme_var.get())).grid(row=4, column=0, padx=5, pady=5)
    ttk.Button(sidebar, text="Open Ping Tool", command=lambda: open_ping_window(theme_var)).grid(row=5, column=0, padx=5, pady=5)
    ttk.Button(sidebar, text="JWT Decoder", command=lambda: open_jwt_window(theme_var)).grid(row=6, column=0, padx=5, pady=5)
    ttk.Button(sidebar, text="SAML Decoder", command=lambda: open_saml_window(theme_var)).grid(row=7, column=0, padx=5, pady=5)
    ttk.Button(sidebar, text="OIDC Debugger", command=lambda: open_oidc_window(theme_var)).grid(row=8, column=0, padx=5, pady=5)
    ttk.Button(sidebar, text="OAuth Debugger", command=lambda: open_oauth_window(theme_var)).grid(row=9, column=0, padx=5, pady=5)
    ttk.Button(sidebar, text="SSL Certificate Reader", command=lambda: open_ssl_cert_reader(theme_var)).grid(row=10, column=0, padx=5, pady=5)

    nslookup = NSLookup(scrollable_frame, theme_var)
    http_request = HTTPRequest(scrollable_frame, theme_var)
    jwks_check = JWKSCheck(scrollable_frame, theme_var)

    for widget in scrollable_frame.winfo_children():
        widget.grid_configure(sticky="nsew")

    scrollable_frame.columnconfigure(0, weight=1)
    scrollable_frame.rowconfigure(1, weight=1)
    scrollable_frame.rowconfigure(2, weight=1)
    scrollable_frame.rowconfigure(3, weight=1)
    scrollable_frame.rowconfigure(4, weight=1)
    scrollable_frame.rowconfigure(5, weight=1)

    apply_theme(theme_var.get())
    nslookup.expand()
    http_request.expand()
    jwks_check.expand()
    root.mainloop()

if __name__ == "__main__":
    main()

